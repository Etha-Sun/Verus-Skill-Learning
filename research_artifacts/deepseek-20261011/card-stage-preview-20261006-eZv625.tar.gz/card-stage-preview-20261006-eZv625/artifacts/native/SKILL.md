# VeruSAGE Executive Skill

Repair only proof and ghost code. Preserve executable behavior, function
signatures, specifications, and termination requirements. Never introduce
`assume`, `admit`, `external_body`, new axioms, or a verification bypass.

Use the current Verus diagnostic as the primary signal. Before editing, classify
the failure (precondition, postcondition, invariant entry/exit, quantifier,
arithmetic, type/mode/scope, or termination), inspect the implicated context,
and choose the narrowest matching VeruSAGE action. Prefer an existing lemma or a
small local assertion over duplicating a proof. Re-run Verus after a meaningful
change; if the same failure repeats, change the proof strategy rather than
repeating the same edit. Accept a candidate only when Verus verifies it and the
proof-only safety comparison passes.

## Proven Verus proof patterns
- In quantified assertions, use `implies` rather than `==>`; `assert forall ... implies ... by { ... }` brings the antecedent into scope. Add `#[trigger]` annotations when Verus reports low confidence or cannot infer triggers; avoid triggers on whole equalities/conjunctions.
- Reuse existing `#[verifier::external_body]` proof rules, open spec functions, macros, and lemmas before writing new proof code; chaining multiple provided lemmas often closes unfolding obligations. For opaque or recursive spec functions, use `reveal_with_fuel(<fn>, <fuel>)` before a failing assertion.
- Prove extensional equality of sequences, sets, maps, or structs pointwise: establish length/cardinality and element/field equality with `assert forall ... by { ... }`, then close using fully qualified macros such as `vstd::assert_seqs_equal!` and `vstd::assert_sets_equal!` rather than a top-level `use` import that may survive deghosting.
- For loops, add a `decreases` clause and include every pre-loop fact needed in the body as an explicit loop invariant; use a ghost accumulator to connect histories/postconditions. For recursive proof functions, add `decreases` as well.
- Use `proof { ... }` (not `ghost { ... }`) for proof-mode mutations, declare ghost state with `let ghost`, and do not rebind executable variables for proof-only purposes; preserve executable code shape for Lynette.
- For constructor/enum injectivity or congruence, case-split on top-level constructors, discharge mismatches by contradiction, then decompose matching branches into field facts and apply field-level lemmas.
- If a recursive spec-function postcondition cannot be proved inline, introduce a small proof-only helper lemma by induction over size/length and call it.
- For `Execution::suffix` equalities, prove pointwise state-function equality for an arbitrary index and apply `execution_equality`; include arithmetic such as `(l + j) + i == l + (j + i)` or `(l + 0) + k == l + k`, and consider a helper lemma for nested suffix shifts.
- Rerun Lynette after structural proof changes; keep executable code unchanged and avoid introducing verification bypasses.
