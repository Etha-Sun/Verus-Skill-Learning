use vstd::prelude::*;
fn main() {}
verus! {

proof fn probe()
    ensures
        seq![1, 2, 3].fold_left(Seq::<int>::empty(), |acc: Seq<int>, x: int| acc.push(x)) ==
            seq![1, 2, 3],
{
    assert(seq![1, 2, 3].fold_left(Seq::<int>::empty(), |acc: Seq<int>, x: int| acc.push(x)) ==
        seq![1, 2, 3]);
}

} // verus!
