use vstd::prelude::*;
fn main() {}
verus! {

proof fn probe()
    ensures
        seq![1int, 2int, 3int].fold_left(Seq::<int>::empty(), |acc: Seq<int>, x: int| acc.push(x)) ==
            seq![3int, 2int, 1int],
{
    assert(seq![1int, 2int, 3int].fold_left(Seq::<int>::empty(), |acc: Seq<int>, x: int| acc.push(x)) ==
        seq![3int, 2int, 1int]);
}

} // verus!
