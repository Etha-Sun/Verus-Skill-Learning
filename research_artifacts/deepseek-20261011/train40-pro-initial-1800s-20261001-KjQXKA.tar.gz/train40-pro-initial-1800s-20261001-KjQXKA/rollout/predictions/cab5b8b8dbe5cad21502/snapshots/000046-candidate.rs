use vstd::prelude::*;
fn main() {}
verus! {

proof fn probe()
{
    let s = seq![1int, 2int, 3int];
    let g = |acc: Seq<int>, x: int| acc.push(x);
    let s_rest = s.drop_last();
    let last = s.last();
    assert(s.fold_left(Seq::<int>::empty(), g) == g(s_rest.fold_left(Seq::<int>::empty(), g), last));
}

} // verus!
