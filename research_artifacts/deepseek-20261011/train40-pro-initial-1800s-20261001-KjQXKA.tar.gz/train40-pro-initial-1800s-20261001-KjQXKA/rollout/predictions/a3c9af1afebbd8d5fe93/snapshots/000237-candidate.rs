extern crate verus_builtin_macros as builtin_macros;
use std::collections;
use vstd::bytes::*;
use vstd::prelude::*;
fn main() {}
verus! {

#[verifier(external_body)]
pub struct CKeyHashMap {
    m: collections::HashMap<CKey, Vec<u8>>,
}

impl CKeyHashMap {
    pub uninterp spec fn view(self) -> Map<AbstractKey, Seq<u8>>;

    pub uninterp spec fn spec_to_vec(&self) -> Vec<CKeyKV>;

    #[verifier(external_body)]
    #[verifier(when_used_as_spec(spec_to_vec))]
    pub fn to_vec(&self) -> (res: Vec<CKeyKV>) {
        unimplemented!()
    }

    pub uninterp spec fn spec_from_vec(v: Vec<CKeyKV>) -> Self;

    #[verifier::external_body]
    pub proof fn lemma_to_vec(self)
        ensures
            Self::spec_from_vec(self.spec_to_vec()) == self,
            self.spec_to_vec().len() == self@.dom().len(),
            spec_sorted_keys(self.spec_to_vec()),
            (forall|i: int|
                #![trigger(self.spec_to_vec() [i])]
                0 <= i < self.spec_to_vec().len() ==> {
                    let (k, v) = self.spec_to_vec()[i]@;
                    self@.contains_pair(k, v)
                }),
    {
        unimplemented!()
    }
}

pub struct CKeyKV {
    pub k: CKey,
    pub v: Vec<u8>,
}

impl CKeyKV {
    pub open spec fn view(self) -> (AbstractKey, Seq<u8>) {
        (self.k, self.v@)
    }
}

pub open spec fn ckeykvlt(a: CKeyKV, b: CKeyKV) -> bool {
    a.k.ukey < b.k.ukey
}

pub open spec fn spec_sorted_keys(v: Vec<CKeyKV>) -> bool {
    forall|i: int, j: int|
        0 <= i && i + 1 < v.len() && j == i + 1 ==> #[trigger] ckeykvlt(v@[i], v@[j])
}

#[derive(Eq, PartialEq, Hash)]
pub struct SHTKey {
    pub ukey: u64,
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_append_len_int<A, B>(
    s: Seq<A>,
    prefix: Seq<B>,
    f: spec_fn(A) -> Seq<B>,
)
    ensures
        s.fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a)).len() as int == s.fold_left(
            prefix.len() as int,
            |i: int, a: A| i + f(a).len() as int,
        ),
    decreases s.len(),
{
    unimplemented!()
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_sum_le<A>(s: Seq<A>, init: int, high: int, f: spec_fn(A) -> int)
    requires
        forall|i: int| 0 <= i < s.len() ==> f(s[i]) <= high,
    ensures
        s.fold_left(init, |acc: int, x: A| acc + f(x)) <= init + s.len() * high,
    decreases s.len(),
{
    unimplemented!()
}

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }
}

impl Marshalable for usize {
    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }
}

impl<T: Marshalable, U: Marshalable> Marshalable for (T, U) {
    open spec fn is_marshalable(&self) -> bool {
        &&& self.0.is_marshalable()
        &&& self.1.is_marshalable()
        &&& self.0.ghost_serialize().len() + self.1.ghost_serialize().len() <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.0.ghost_serialize() + self.1.ghost_serialize()
    }
}

macro_rules! derive_marshalable_for_struct { { $(#[$attr :
    meta])* $pub : vis struct $newstruct : ident $(< $($poly : ident : Marshalable),+
    $(,)? >)? { $($fieldvis : vis $field : ident : $fieldty : ty),+ $(,)? } } => {
    ::builtin_macros::verus! { impl $(< $($poly : Marshalable),* >)? Marshalable for
    $newstruct $(< $($poly),* >)? { open spec fn is_marshalable(& self) -> bool { $(&&&
    self.$field .is_marshalable())* &&& 0 $(+ self.$field .ghost_serialize().len())* <=
    usize::MAX } open spec fn ghost_serialize(& self) -> Seq < u8 > { Seq::empty() $(+
    self.$field .ghost_serialize())* } } } } }

macro_rules! marshalable_by_bijection { {
    [$type : ty] <-> [$marshalable : ty]; forward($self : ident) $forward : expr;
    backward($m : ident) $backward : expr; } => { ::builtin_macros::verus! { impl $type {
    pub open spec fn
    forward_bijection_for_view_equality_do_not_use_for_anything_else($self : Self) ->
    $marshalable { $forward } } impl Marshalable for $type { open spec fn
    is_marshalable($self : & Self) -> bool { $forward .is_marshalable() } open spec fn
    ghost_serialize($self : & Self) -> Seq < u8 > { $forward .ghost_serialize() } } } } }

#[verifier::opaque]
pub open spec fn ckeyhashmap_max_serialized_size() -> usize {
    0x100000
}

impl Marshalable for CKeyHashMap {
    open spec fn is_marshalable(&self) -> bool {
        self.to_vec().is_marshalable() && spec_sorted_keys(self.to_vec())
            && self.to_vec().ghost_serialize().len() <= (ckeyhashmap_max_serialized_size() as int)
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.to_vec().ghost_serialize()
    }
}

pub open spec fn max_val_len() -> int {
    1024
}

pub open spec fn valid_key(key: AbstractKey) -> bool {
    true
}

pub open spec fn valid_value(value: AbstractValue) -> bool {
    value.len() < max_val_len()
}

pub open spec fn max_hashtable_size() -> int {
    62
}

pub open spec fn valid_hashtable(h: Hashtable) -> bool {
    &&& h.dom().len() < max_hashtable_size()
    &&& (forall|k| h.dom().contains(k) ==> valid_key(k) && #[trigger] valid_value(h[k]))
}

pub type CKey = SHTKey;

pub type AbstractKey = SHTKey;

pub type AbstractValue = Seq<u8>;

pub type Hashtable = Map<AbstractKey, AbstractValue>;

marshalable_by_bijection! { [SHTKey] <-> [u64]; forward(self) self
    .ukey; backward(x) SHTKey { ukey : x }; }

derive_marshalable_for_struct! { pub struct
    CKeyKV { pub k : CKey, pub v : Vec::< u8 >, } }

#[allow(non_snake_case)]
pub proof fn lemma_CKeyKV_is_marshalable(kv: CKeyKV)
    requires
        valid_value(kv.v@),
    ensures
        kv.is_marshalable(),
{
    assert(kv.k.is_marshalable());
    assert(kv.v@.len() < 1024);
    assert(kv.v@.len() <= usize::MAX);
    lemma_u64_ser_len(kv.v@.len() as u64);
    assert((kv.v@.len() as usize).ghost_serialize().len() == 8);
    assert(kv.v.is_marshalable()) by {
        assert((kv.v@.len() as usize).ghost_serialize().len() + kv.v@.len() <= usize::MAX);
    }
    lemma_u64_ser_len(kv.k.ukey);
    assert(kv.k.ghost_serialize().len() == 8);
    assert(kv.v.ghost_serialize().len() <= 1031);
    assert(kv.k.ghost_serialize().len() + kv.v.ghost_serialize().len() <= usize::MAX);
    assert(kv.is_marshalable());
}

#[allow(non_snake_case)]
pub proof fn lemma_u64_ser_len(x: u64)
    ensures
        x.ghost_serialize().len() == 8,
{
    assert(x.ghost_serialize() == spec_u64_to_le_bytes(x));
    spec_u64_to_le_bytes_to_open(x);
    assert(spec_u64_to_le_bytes_open(x).len() == 8);
    assert(spec_u64_to_le_bytes_open(x) == spec_u64_to_le_bytes(x));
}

#[allow(non_snake_case)]
pub proof fn test_seq_new_len()
{
    let s = Seq::<u8>::new(8, |i: int| 0u8);
    assert(s.len() == 8);
}

#[allow(non_snake_case)]
pub proof fn lemma_contains_implies_exists<A>(s: Seq<A>, x: A)
    requires
        s.contains(x),
    ensures
        exists|i: int| 0 <= i < s.len() && s[i] == x,
{
}

#[allow(non_snake_case)]
pub proof fn lemma_seq_fold_left_sum_le_CKeyKV(s: Seq<CKeyKV>, init: int, high: int)
    requires
        forall|i: int| 0 <= i < s.len() ==> s[i].ghost_serialize().len() <= high,
    ensures
        s.fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) <= init + s.len() * high,
    decreases s.len(),
{
    if s.len() == 0 {
        reveal_with_fuel(Seq::fold_left, 2);
        assert(s.fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) == init);
    } else {
        let sl = s.drop_last();
        let last = s.last();
        assert(sl.len() == s.len() - 1);
        assert(s[s.len() - 1] == last);
        assert(last.ghost_serialize().len() <= high);
        lemma_seq_fold_left_sum_le_CKeyKV(sl, init, high);
        assert(sl.fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) <= init + sl
            .len() * high);
        reveal_with_fuel(Seq::fold_left, 2);
        assert(s.fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) == sl
            .fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) + last
            .ghost_serialize().len());
        assert(s.fold_left(init, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) <= init + s
            .len() * high);
    }
}

#[allow(non_snake_case)]
pub proof fn lemma_seq_fold_left_append_len_CKeyKV(s: Seq<CKeyKV>)
    ensures
        s.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize()).len()
            == s.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()),
    decreases s.len(),
{
    if s.len() == 0 {
        reveal_with_fuel(Seq::fold_left, 2);
        assert(s.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize()).len()
            == 0);
        assert(s.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) == 0);
    } else {
        let sl = s.drop_last();
        let last = s.last();
        lemma_seq_fold_left_append_len_CKeyKV(sl);
        assert(sl.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize()).len()
            == sl.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()));
        reveal_with_fuel(Seq::fold_left, 2);
        assert(s.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize())
            == sl.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize())
                + last.ghost_serialize());
        assert(s.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) == sl.fold_left(
            0,
            |acc: int, x: CKeyKV| acc + x.ghost_serialize().len(),
        ) + last.ghost_serialize().len());
        assert(s.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize()).len()
            == s.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()));
    }
}

#[allow(non_snake_case)]
#[allow(non_snake_case)]
pub proof fn lemma_is_marshalable_CKeyHashMap(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
    ensures
        h.is_marshalable(),
{
    h.lemma_to_vec();
    assert(spec_sorted_keys(h.spec_to_vec()));
    assert(h.spec_to_vec().len() == h@.dom().len());
    assert(h.spec_to_vec().len() <= 61);
    assert(h.spec_to_vec().len() <= usize::MAX);

    assert forall|i: int| 0 <= i < h.spec_to_vec().len() ==> h.spec_to_vec()[i].is_marshalable() by {
        assert forall|i: int| 0 <= i < h.spec_to_vec().len() implies h.spec_to_vec()[i].is_marshalable() by {
            let (k, v) = h.spec_to_vec()[i]@;
            assert(h@.contains_pair(k, v));
            assert(h@.dom().contains(k));
            assert(h@[k] == v);
            assert(valid_value(h@[k]));
            assert(valid_value(v));
            lemma_CKeyKV_is_marshalable(h.spec_to_vec()[i]);
        }
    }

    assert forall|i: int| 0 <= i < h.spec_to_vec().len() ==> h.spec_to_vec()[i].ghost_serialize()
        .len() <= 1039 by {
        assert forall|i: int| 0 <= i < h.spec_to_vec().len() implies h.spec_to_vec()[i]
            .ghost_serialize().len() <= 1039 by {
            let (k, v) = h.spec_to_vec()[i]@;
            assert(h@.contains_pair(k, v));
            assert(h@.dom().contains(k));
            assert(h@[k] == v);
            assert(valid_value(h@[k]));
            assert(valid_value(v));
            assert(v.len() < 1024);
            lemma_u64_ser_len(k.ukey);
            assert(k.ghost_serialize().len() == 8);
            lemma_u64_ser_len(v.len() as u64);
            assert((v.len() as usize).ghost_serialize().len() == 8);
            assert(h.spec_to_vec()[i].v.ghost_serialize().len() <= 1031);
            assert(h.spec_to_vec()[i].ghost_serialize().len() <= 1039);
        }
    }

    assert forall|x: CKeyKV| h.spec_to_vec()@.contains(x) ==> x.is_marshalable() by {
        assert forall|x: CKeyKV| h.spec_to_vec()@.contains(x) implies x.is_marshalable() by {
            lemma_contains_implies_exists(h.spec_to_vec()@, x);
            let i = choose|i: int| 0 <= i < h.spec_to_vec()@.len() && h.spec_to_vec()@[i] == x;
            assert(h.spec_to_vec()@[i].is_marshalable());
            assert(x.is_marshalable());
        }
    }

    lemma_seq_fold_left_sum_le_CKeyKV(h.spec_to_vec()@, 0, 1039);
    lemma_u64_ser_len(h.spec_to_vec().len() as u64);
    assert((h.spec_to_vec().len() as usize).ghost_serialize().len() == 8);
    assert(h.spec_to_vec()@.len() <= 61);
    assert(h.spec_to_vec()@.fold_left(
        0,
        |acc: int, x: CKeyKV| acc + x.ghost_serialize().len(),
    ) <= 61 * 1039);
    assert((h.spec_to_vec().len() as usize).ghost_serialize().len() + h.spec_to_vec()@.fold_left(
        0,
        |acc: int, x: CKeyKV| acc + x.ghost_serialize().len(),
    ) <= usize::MAX);

    assert(h.spec_to_vec().is_marshalable());

    lemma_seq_fold_left_append_len_CKeyKV(h.spec_to_vec()@);
    reveal(ckeyhashmap_max_serialized_size);
    assert(h.spec_to_vec().ghost_serialize().len() <= 0x100000);
    assert(spec_sorted_keys(h.spec_to_vec()));
    assert(h.is_marshalable());
}

} // verus!
