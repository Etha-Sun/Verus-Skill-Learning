use vstd::prelude::*;
use vstd::assert_sets_equal;

fn main() {}

verus! {

pub trait VerusClone: Sized {}

pub struct EndPoint {
    pub id: Vec<u8>,
}

type ID = EndPoint;

pub enum Ordering {
    Less,
    Equal,
    Greater,
}

impl Ordering {
    pub open spec fn lt(self) -> bool {
        matches!(self, Ordering::Less)
    }
}

pub trait KeyTrait: Sized {
    spec fn cmp_spec(self, other: Self) -> Ordering;
}

spec fn sorted<K: KeyTrait>(s: Seq<K>) -> bool {
    forall|i, j| #![auto] 0 <= i < j < s.len() ==> s[i].cmp_spec(s[j]).lt()
}

struct StrictlyOrderedVec<K: KeyTrait> {
    v: Vec<K>,
}

proof fn lemma_remove_set_contains_equiv<K>(s: Seq<K>, i: int, e: K)
    requires
        0 <= i < s.len(),
        s.no_duplicates(),
    ensures
        s.remove(i).to_set().contains(e) == s.to_set().remove(s.index(i)).contains(e),
{
    let t = s.remove(i);
    assert(t.to_set().contains(e) == t.contains(e));
    assert(s.to_set().contains(e) == s.contains(e));
    assert(s.to_set().remove(s.index(i)).contains(e) ==
        (s.to_set().contains(e) && e != s.index(i)));
    if t.contains(e) {
        let j = choose|j: int| 0 <= j < t.len() && t.index(j) == e;
        assert(0 <= j < t.len());
        assert(t.index(j) == e);
        if j < i {
            assert(t.index(j) == s.index(j));
            assert(s.index(j) == e);
            assert(s.index(j) != s.index(i));
            assert(e != s.index(i));
        } else {
            assert(t.index(j) == s.index(j + 1));
            assert(s.index(j + 1) == e);
            assert(s.index(j + 1) != s.index(i));
            assert(e != s.index(i));
        }
        assert(s.contains(e));
        assert(s.to_set().contains(e));
        assert(s.to_set().remove(s.index(i)).contains(e));
    } else {
        if s.to_set().remove(s.index(i)).contains(e) {
            assert(s.to_set().contains(e) && e != s.index(i));
            assert(s.contains(e));
            let j = choose|j: int| 0 <= j < s.len() && s.index(j) == e;
            assert(0 <= j < s.len());
            assert(s.index(j) == e);
            assert(j != i);
            if j < i {
                assert(t.index(j) == s.index(j));
                assert(t.index(j) == e);
                assert(0 <= j < t.len());
                assert(t.contains(e));
            } else {
                assert(j > i);
                assert(t.index(j - 1) == s.index(j));
                assert(t.index(j - 1) == e);
                assert(0 <= j - 1 < t.len());
                assert(t.contains(e));
            }
            assert(false);
        }
    }
}

proof fn lemma_remove_to_set<K>(s: Seq<K>, i: int)
    requires
        0 <= i < s.len(),
        s.no_duplicates(),
    ensures
        s.remove(i).to_set() == s.to_set().remove(s.index(i)),
{
    assert forall|e| #![auto] s.remove(i).to_set().contains(e) ==
        s.to_set().remove(s.index(i)).contains(e) by {
        lemma_remove_set_contains_equiv(s, i, e);
    };
    assert_sets_equal!(s.remove(i).to_set(), s.to_set().remove(s.index(i)));
}

impl<K: KeyTrait + VerusClone> StrictlyOrderedVec<K> {
    pub closed spec fn view(self) -> Seq<K> {
        self.v@
    }

    pub closed spec fn valid(self) -> bool {
        sorted(self@) && self@.no_duplicates()
    }

    fn remove(&mut self, i: usize) -> (k: K)
        requires
            old(self).valid(),
            i < old(self)@.len(),
        ensures
            self.valid(),
            k == old(self)@.index(i as int),
            self@ == old(self)@.remove(i as int),
            self@.to_set() == old(self)@.to_set().remove(k),
    {
        let k = self.v.remove(i);
        proof {
            let s = old(self)@;
            assert(k == s.index(i as int));
            assert(s.no_duplicates());
            lemma_remove_to_set::<K>(s, i as int);
        }
        k
    }
}

} // verus!
