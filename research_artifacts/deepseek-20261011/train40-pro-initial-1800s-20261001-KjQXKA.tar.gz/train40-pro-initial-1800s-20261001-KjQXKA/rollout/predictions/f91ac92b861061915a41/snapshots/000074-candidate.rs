use vstd::prelude::*;
use vstd::assert_seqs_equal;

fn main() {}

verus!{


pub proof fn seq_equal_preserved_by_add<A>(s1: Seq<A>, s2: Seq<A>, suffix: Seq<A>)
    ensures s1 == s2 <==> s1 + suffix == s2 + suffix
{
    if s1 == s2 {
        assert(s1.len() == s2.len());
        assert((s1 + suffix).len() == (s2 + suffix).len());
        assert forall |i| 0 <= i < (s1 + suffix).len() implies
            #[trigger] (s1 + suffix)[i] == #[trigger] (s2 + suffix)[i] by {
            if i < s1.len() {
                assert(s1[i] == s2[i]);
            } else {
                assert(suffix[i - s1.len()] == suffix[i - s2.len()]);
            }
        };
        assert_seqs_equal!(s1 + suffix, s2 + suffix);
    } else {
        if s1 + suffix == s2 + suffix {
            assert((s1 + suffix).len() == (s2 + suffix).len());
            assert(s1.len() == s2.len());
            assert forall |i| 0 <= i < s1.len() implies
                #[trigger] s1[i] == #[trigger] s2[i] by {
                assert((s1 + suffix)[i] == (s2 + suffix)[i]);
                assert((s1 + suffix)[i] == s1[i]);
                assert((s2 + suffix)[i] == s2[i]);
            };
            assert_seqs_equal!(s1, s2);
            assert(false);
        }
    }
}

}
