use vstd::prelude::*;
fn main() {}
verus! {

pub proof fn set_map_union<A, B>(s1: Set<A>, s2: Set<A>, f: spec_fn(A) -> B)
    ensures
        (s1 + s2).map(f) == s1.map(f) + s2.map(f),
{
    assert forall |b| (s1 + s2).map(f).contains(b) == (s1.map(f) + s2.map(f)).contains(b) by {
        if (s1 + s2).map(f).contains(b) {
            assert((s1.map(f) + s2.map(f)).contains(b));
        } else {
            assert(!(s1.map(f) + s2.map(f)).contains(b));
        }
    };
    assert((s1 + s2).map(f) == s1.map(f) + s2.map(f));
}

} // verus!
