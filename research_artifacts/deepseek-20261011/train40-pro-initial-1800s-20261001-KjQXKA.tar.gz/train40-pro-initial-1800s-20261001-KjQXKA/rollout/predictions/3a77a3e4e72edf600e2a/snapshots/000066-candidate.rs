use vstd::prelude::*;
fn main() {}
verus! {

pub proof fn set_map_union<A, B>(s1: Set<A>, s2: Set<A>, f: spec_fn(A) -> B)
    ensures
        (s1 + s2).map(f) == s1.map(f) + s2.map(f),
{
    assert forall |b| #![auto] (s1 + s2).map(f).contains(b)
        == (s1.map(f) + s2.map(f)).contains(b) by {
        if (s1 + s2).map(f).contains(b) {
            assert((s1.map(f) + s2.map(f)).contains(b));
        } else {
            if s1.map(f).contains(b) {
                let a = choose |a: A| s1.contains(a) && f(a) == b;
                assert(s1.contains(a));
                assert(f(a) == b);
                assert((s1 + s2).contains(a));
                assert((s1 + s2).map(f).contains(b));
                assert(false);
            } else if s2.map(f).contains(b) {
                let a = choose |a: A| s2.contains(a) && f(a) == b;
                assert(s2.contains(a));
                assert(f(a) == b);
                assert((s1 + s2).contains(a));
                assert((s1 + s2).map(f).contains(b));
                assert(false);
            }
        }
    };
    assert((s1 + s2).map(f) == s1.map(f) + s2.map(f));
}

} // verus!
