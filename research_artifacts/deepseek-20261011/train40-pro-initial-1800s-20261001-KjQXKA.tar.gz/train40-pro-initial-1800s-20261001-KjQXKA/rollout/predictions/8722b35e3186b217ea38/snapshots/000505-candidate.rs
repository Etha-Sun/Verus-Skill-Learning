use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| #[trigger] temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn eliminate_always<T>(spec: TempPred<T>, p: TempPred<T>)
    requires spec.entails(always(p)),
    ensures spec.entails(p),
{
    assert forall |s: TempPred<T>, q: TempPred<T>, ex: Execution<T>|
        s.entails(always(q)) ==> (s.satisfied_by(ex) ==> q.satisfied_by(ex))
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let ex: Execution<T>;
        if s.entails(always(q)) {
            if s.satisfied_by(ex) {
                eliminate_always_at(s, q, ex);
            }
        }
    }
    assert(forall |ex: Execution<T>| (spec.implies(p)).satisfied_by(ex));
}

proof fn eliminate_always_at<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>)
    requires
        spec.entails(always(p)),
        spec.satisfied_by(ex),
    ensures p.satisfied_by(ex),
{
    valid_at(spec.implies(always(p)), ex);
    implies_apply(ex, spec, always(p));
    assert(p.satisfied_by(ex.suffix(0)));
    execution_equality(ex.suffix(0), ex);
    assert(ex.suffix(0) == ex);
    assert(p.satisfied_by(ex));
}

proof fn valid_at<T>(q: TempPred<T>, ex: Execution<T>)
    requires valid(q),
    ensures q.satisfied_by(ex),
{
}

#[verifier::external_body]
proof fn probe_bridge2<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    requires q.satisfied_by(ex),
    ensures r.satisfied_by(ex),
{
    unimplemented!()
}

proof fn probe_h20<T>()
{
    assert forall |q: TempPred<T>, r: TempPred<T>, ex: Execution<T>|
        q.satisfied_by(ex) ==> r.satisfied_by(ex)
    by {
        let q: TempPred<T>;
        let r: TempPred<T>;
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_bridge2(q, r, ex);
        }
    }
}

pub closed spec fn sat2<T>(s: TempPred<T>, ex: Execution<T>) -> bool {
    s.satisfied_by(ex)
}

#[verifier::external_body]
proof fn probe_bridge2b<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    requires sat2(q, ex),
    ensures sat2(r, ex),
{
    unimplemented!()
}

proof fn probe_h21<T>()
{
    assert forall |q: TempPred<T>, r: TempPred<T>, ex: Execution<T>|
        sat2(q, ex) ==> sat2(r, ex)
    by {
        let q: TempPred<T>;
        let r: TempPred<T>;
        let ex: Execution<T>;
        if sat2(q, ex) {
            probe_bridge2b(q, r, ex);
        }
    }
}

pub closed spec fn probe_c2(x: int) -> bool {
    x == 3
}

pub closed spec fn probe_d2(x: int) -> bool {
    x == 5
}

#[verifier::external_body]
proof fn probe_bridge_multi(x: int, y: int)
    requires probe_c2(x),
    ensures probe_d2(y),
{
    unimplemented!()
}

proof fn probe_h22()
{
    assert forall |x: int, y: int| probe_c2(x) ==> probe_d2(y) by {
        let x: int;
        let y: int;
        if probe_c2(x) {
            probe_bridge_multi(x, y);
        }
    }
}

proof fn probe_h23()
{
    assert forall |x: int| probe_c2(x) ==> probe_d2(x) by {
        let x: int;
        if probe_c2(x) {
            probe_bridge_multi(x, x);
        }
    }
}

pub closed spec fn probe_d2b(x: int) -> bool {
    x == 3
}

proof fn probe_bridge_real(x: int)
    requires probe_c2(x),
    ensures probe_d2b(x),
{
    reveal(probe_c2);
    reveal(probe_d2b);
}

proof fn probe_h24()
{
    assert forall |x: int| probe_c2(x) ==> probe_d2b(x) by {
        let x: int;
        if probe_c2(x) {
            probe_bridge_real(x);
        }
    }
}

#[verifier::external_body]
proof fn ext_noop(x: int)
    requires probe_c2(x),
    ensures probe_d2b(x),
{
    unimplemented!()
}

proof fn probe_bridge_real2(x: int)
    requires probe_c2(x),
    ensures probe_d2b(x),
{
    ext_noop(x);
}

proof fn probe_h25()
{
    assert forall |x: int| probe_c2(x) ==> probe_d2b(x) by {
        let x: int;
        if probe_c2(x) {
            probe_bridge_real2(x);
        }
    }
}

proof fn probe_bridge_real_multi(x: int, y: int)
    requires probe_c2(x),
    ensures probe_d2b(x),
{
    reveal(probe_c2);
    reveal(probe_d2b);
}

proof fn probe_h27()
{
    assert forall |x: int, y: int| probe_c2(x) ==> (probe_c2(y) ==> probe_d2b(x)) by {
        let x: int;
        let y: int;
        if probe_c2(x) {
            if probe_c2(y) {
                probe_bridge_real(x);
            }
        }
    }
}

pub closed spec fn ent_wrap<T>(s: TempPred<T>, q: TempPred<T>) -> bool {
    s.entails(always(q))
}

proof fn generic_real_bridge2<T>(s: TempPred<T>, q: TempPred<T>, ex: Execution<T>)
    requires
        ent_wrap(s, q),
        sat2(s, ex),
    ensures sat2(q, ex),
{
    reveal(ent_wrap);
    reveal(sat2);
    eliminate_always_at(s, q, ex);
    reveal(sat2);
}

proof fn probe_h29<T>()
{
    assert forall |s: TempPred<T>, q: TempPred<T>, ex: Execution<T>|
        ent_wrap(s, q) ==> (sat2(s, ex) ==> sat2(q, ex))
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let ex: Execution<T>;
        if ent_wrap(s, q) {
            if sat2(s, ex) {
                generic_real_bridge2(s, q, ex);
                assert(sat2(q, ex));
            }
        }
    }
}

pub closed spec fn gen_a<T>(x: T, c: T) -> bool {
    x == c
}

pub closed spec fn gen_b<T>(x: T, c: T) -> bool {
    x == c
}

proof fn gen_bridge_real<T>(x: T, c: T)
    requires gen_a(x, c),
    ensures gen_b(x, c),
{
    reveal(gen_a);
    reveal(gen_b);
}

proof fn probe_h30<T>()
{
    assert forall |x: T, c: T| gen_a(x, c) ==> gen_b(x, c) by {
        let x: T;
        let c: T;
        if gen_a(x, c) {
            gen_bridge_real(x, c);
        }
    }
}

pub closed spec fn tp_a<T>(q: TempPred<T>) -> bool {
    valid(q)
}

pub closed spec fn tp_b<T>(q: TempPred<T>) -> bool {
    valid(q)
}

proof fn tp_bridge<T>(q: TempPred<T>)
    requires tp_a(q),
    ensures tp_b(q),
{
    reveal(tp_a);
    reveal(tp_b);
}

proof fn probe_h31<T>()
{
    assert forall |q: TempPred<T>, r: TempPred<T>| tp_a(q) ==> (tp_a(r) ==> tp_b(q)) by {
        let q: TempPred<T>;
        let r: TempPred<T>;
        if tp_a(q) {
            if tp_a(r) {
                tp_bridge(q);
            }
        }
    }
}

proof fn probe_h32()
{
    assert forall |ex: Execution<nat>| (ex.nat_to_state)(0) == (ex.nat_to_state)(0) by {
        let ex: Execution<nat>;
    }
}

pub closed spec fn ex_c(ex: Execution<nat>) -> bool {
    (ex.nat_to_state)(0) == (ex.nat_to_state)(0)
}

pub closed spec fn ex_d(ex: Execution<nat>) -> bool {
    (ex.nat_to_state)(0) == (ex.nat_to_state)(0)
}

proof fn ex_bridge(ex: Execution<nat>)
    requires ex_c(ex),
    ensures ex_d(ex),
{
    reveal(ex_c);
    reveal(ex_d);
}

proof fn probe_h33()
{
    assert forall |ex: Execution<nat>| ex_c(ex) ==> ex_d(ex) by {
        let ex: Execution<nat>;
        if ex_c(ex) {
            ex_bridge(ex);
        }
    }
}

pub closed spec fn ex_c2<T>(ex: Execution<T>, w: T) -> bool {
    (ex.nat_to_state)(0) == w
}

pub closed spec fn ex_d2<T>(ex: Execution<T>, w: T) -> bool {
    (ex.nat_to_state)(0) == w
}

proof fn ex_bridge2<T>(ex: Execution<T>, w: T)
    requires ex_c2(ex, w),
    ensures ex_d2(ex, w),
{
    reveal(ex_c2);
    reveal(ex_d2);
}

proof fn probe_h34<T>()
{
    assert forall |ex: Execution<T>, w: T| ex_c2(ex, w) ==> ex_d2(ex, w) by {
        let ex: Execution<T>;
        let w: T;
        if ex_c2(ex, w) {
            ex_bridge2(ex, w);
        }
    }
}

pub closed spec fn combo_a<T>(s: TempPred<T>, ex: Execution<T>) -> bool {
    s.satisfied_by(ex)
}

pub closed spec fn combo_b<T>(s: TempPred<T>, ex: Execution<T>) -> bool {
    s.satisfied_by(ex)
}

proof fn combo_bridge<T>(s: TempPred<T>, ex: Execution<T>)
    requires combo_a(s, ex),
    ensures combo_b(s, ex),
{
    reveal(combo_a);
    reveal(combo_b);
}

proof fn probe_h36<T>()
{
    assert forall |s: TempPred<T>, q: TempPred<T>, ex: Execution<T>|
        combo_a(s, ex) ==> (combo_a(q, ex) ==> combo_b(s, ex))
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let ex: Execution<T>;
        if combo_a(s, ex) {
            if combo_a(q, ex) {
                combo_bridge(s, ex);
            }
        }
    }
}

pub closed spec fn ent_wrap2<T>(s: TempPred<T>, q: TempPred<T>) -> bool {
    valid(s) && valid(q)
}

proof fn bridge39<T>(s: TempPred<T>, q: TempPred<T>, r: TempPred<T>)
    requires
        ent_wrap2(s, q),
        tp_a(r),
    ensures tp_b(q),
{
    reveal(ent_wrap2);
    reveal(tp_a);
    reveal(tp_b);
}

proof fn probe_h39<T>()
{
    assert forall |s: TempPred<T>, q: TempPred<T>, r: TempPred<T>|
        ent_wrap2(s, q) ==> (tp_a(r) ==> tp_b(q))
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let r: TempPred<T>;
        if ent_wrap2(s, q) {
            if tp_a(r) {
                bridge39(s, q, r);
            }
        }
    }
}

proof fn bridge29b<T>(s: TempPred<T>, q: TempPred<T>, ex: Execution<T>)
    requires
        ent_wrap(s, q),
        sat2(s, ex),
    ensures sat2(s, ex),
{
}

proof fn probe_h40<T>()
{
    assert forall |s: TempPred<T>, q: TempPred<T>, ex: Execution<T>|
        ent_wrap(s, q) ==> (sat2(s, ex) ==> sat2(s, ex))
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let ex: Execution<T>;
        if ent_wrap(s, q) {
            if sat2(s, ex) {
                bridge29b(s, q, ex);
            }
        }
    }
}


}
