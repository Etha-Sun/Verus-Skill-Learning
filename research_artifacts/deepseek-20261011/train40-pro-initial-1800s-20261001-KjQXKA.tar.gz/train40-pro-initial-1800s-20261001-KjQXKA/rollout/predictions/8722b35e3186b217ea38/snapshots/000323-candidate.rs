use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| #[trigger] temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn eliminate_always<T>(spec: TempPred<T>, p: TempPred<T>)
    requires spec.entails(always(p)),
    ensures spec.entails(p),
{
    assert forall |s: TempPred<T>, q: TempPred<T>, ex: Execution<T>|
        s.entails(always(q)) ==> (s.implies(q)).satisfied_by(ex)
    by {
        let s: TempPred<T>;
        let q: TempPred<T>;
        let ex: Execution<T>;
        if s.entails(always(q)) {
            if s.satisfied_by(ex) {
                eliminate_always_at(s, q, ex);
            }
        }
    }
    assert forall |ex: Execution<T>| (spec.implies(p)).satisfied_by(ex);
}

proof fn eliminate_always_at<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>)
    requires
        spec.entails(always(p)),
        spec.satisfied_by(ex),
    ensures p.satisfied_by(ex),
{
    valid_at(spec.implies(always(p)), ex);
    implies_apply(ex, spec, always(p));
    assert(p.satisfied_by(ex.suffix(0)));
    execution_equality(ex.suffix(0), ex);
    assert(ex.suffix(0) == ex);
    assert(p.satisfied_by(ex));
}

proof fn valid_at<T>(q: TempPred<T>, ex: Execution<T>)
    requires valid(q),
    ensures q.satisfied_by(ex),
{
}


}
