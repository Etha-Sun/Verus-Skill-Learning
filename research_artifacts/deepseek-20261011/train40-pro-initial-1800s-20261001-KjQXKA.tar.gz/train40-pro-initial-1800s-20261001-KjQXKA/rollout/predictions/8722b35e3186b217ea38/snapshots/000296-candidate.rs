use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| #[trigger] temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn eliminate_always<T>(spec: TempPred<T>, p: TempPred<T>)
    requires spec.entails(always(p)),
    ensures spec.entails(p),
{
    assert forall |ex: Execution<T>| spec_implies_p_at(spec, p, ex) by {
        let ex: Execution<T>;
        if spec.satisfied_by(ex) {
            eliminate_always_at(spec, p, ex);
            assert(p.satisfied_by(ex));
        }
    }
}

pub open spec fn spec_implies_p_at<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>) -> bool {
    spec.satisfied_by(ex) ==> p.satisfied_by(ex)
}

proof fn implies_at_wrapper<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>)
    requires spec.entails(always(p)),
    ensures spec_implies_p_at(spec, p, ex),
{
    if spec.satisfied_by(ex) {
        eliminate_always_at(spec, p, ex);
        assert(spec_implies_p_at(spec, p, ex));
    } else {
        assert(spec_implies_p_at(spec, p, ex));
    }
}

proof fn entails_at<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>)
    requires spec.entails(always(p)),
    ensures spec.satisfied_by(ex) ==> p.satisfied_by(ex),
{
    if spec.satisfied_by(ex) {
        eliminate_always_at(spec, p, ex);
    }
}

proof fn eliminate_always_at<T>(spec: TempPred<T>, p: TempPred<T>, ex: Execution<T>)
    requires
        spec.entails(always(p)),
        spec.satisfied_by(ex),
    ensures p.satisfied_by(ex),
{
    valid_at(spec.implies(always(p)), ex);
    implies_apply(ex, spec, always(p));
    assert(p.satisfied_by(ex.suffix(0)));
    execution_equality(ex.suffix(0), ex);
    assert(ex.suffix(0) == ex);
    assert(p.satisfied_by(ex));
}

proof fn valid_at<T>(q: TempPred<T>, ex: Execution<T>)
    requires valid(q),
    ensures q.satisfied_by(ex),
{
}

pub open spec fn probe_imp(i: nat) -> bool {
    i < 5 ==> i == i
}

proof fn probe_lemma2(i: nat)
    ensures probe_imp(i),
{
    if i < 5 {
        assert(i == i);
    }
}

proof fn probe_g()
{
    assert forall |i: nat| probe_imp(i) by {
        let i: nat;
        probe_lemma2(i);
    }
}

proof fn probe_need_lemma(i: nat)
    requires i < 5,
    ensures i != 5,
{
}

pub open spec fn probe_disc_body(i: nat) -> bool {
    i < 5 ==> i != 5
}

proof fn probe_disc()
{
    assert forall |i: nat| probe_disc_body(i) by {
        let i: nat;
        if i < 5 {
            probe_need_lemma(i);
        }
    }
}

pub closed spec fn probe_a(x: int) -> bool {
    x == 3
}

pub closed spec fn probe_b(x: int) -> bool {
    x == 3
}

proof fn probe_lemma7(x: int)
    requires probe_a(x),
    ensures probe_b(x),
{
    reveal(probe_a);
    reveal(probe_b);
}

pub open spec fn probe_body7(x: int) -> bool {
    probe_a(x) ==> probe_b(x)
}

proof fn probe_h4()
{
    assert forall |x: int| probe_body7(x) by {
        let x: int;
        if probe_a(x) {
            probe_lemma7(x);
        }
    }
}

proof fn probe_lemma8<T>(q: TempPred<T>, ex: Execution<T>)
    requires q.satisfied_by(ex),
    ensures q.satisfied_by(ex),
{
}

pub open spec fn probe_body8<T>(q: TempPred<T>, ex: Execution<T>) -> bool {
    q.satisfied_by(ex) ==> q.satisfied_by(ex)
}

proof fn probe_h5<T>(q: TempPred<T>)
{
    assert forall |ex: Execution<T>| probe_body8(q, ex) by {
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_lemma8(q, ex);
        }
    }
}

proof fn probe_lemma9<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    requires
        valid(q.implies(r)),
        q.satisfied_by(ex),
    ensures r.satisfied_by(ex),
{
    valid_at(q.implies(r), ex);
    implies_apply(ex, q, r);
}

pub open spec fn probe_body9<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>) -> bool {
    q.satisfied_by(ex) ==> r.satisfied_by(ex)
}

proof fn probe_h6<T>(q: TempPred<T>, r: TempPred<T>)
    requires valid(q.implies(r)),
{
    assert forall |ex: Execution<T>| probe_body9(q, r, ex) by {
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_lemma9(q, r, ex);
            assert(r.satisfied_by(ex));
        }
    }
}

proof fn probe_h6_direct<T>(q: TempPred<T>, r: TempPred<T>)
    requires valid(q.implies(r)),
{
    assert forall |ex: Execution<T>| q.satisfied_by(ex) ==> r.satisfied_by(ex) by {
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_lemma9(q, r, ex);
        }
    }
}

#[verifier::external_body]
proof fn probe_bridge2<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    requires q.satisfied_by(ex),
    ensures r.satisfied_by(ex),
{
    unimplemented!()
}

proof fn probe_h9<T>(q: TempPred<T>, r: TempPred<T>)
{
    assert forall |ex: Execution<T>| probe_body9(q, r, ex) by {
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_bridge2(q, r, ex);
        }
    }
}

pub closed spec fn sat_wrapper<T>(q: TempPred<T>, ex: Execution<T>) -> bool {
    q.satisfied_by(ex)
}

pub open spec fn probe_body10<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>) -> bool {
    sat_wrapper(q, ex) ==> sat_wrapper(r, ex)
}

#[verifier::external_body]
proof fn probe_bridge5<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    requires sat_wrapper(q, ex),
    ensures sat_wrapper(r, ex),
{
    unimplemented!()
}

proof fn probe_h12<T>(q: TempPred<T>, r: TempPred<T>)
{
    assert forall |ex: Execution<T>| probe_body10(q, r, ex) by {
        let ex: Execution<T>;
        if sat_wrapper(q, ex) {
            probe_bridge5(q, r, ex);
        }
    }
}

proof fn probe_h13<T>(q: TempPred<T>, r: TempPred<T>)
{
    assert forall |ex: Execution<T>| probe_body9(q, r, ex) by {
        let ex: Execution<T>;
        if q.satisfied_by(ex) {
            probe_bridge2(q, r, ex);
            assert(probe_body9(q, r, ex));
        } else {
            assert(probe_body9(q, r, ex));
        }
    }
}

#[verifier::external_body]
proof fn probe_bridge3<T>(q: TempPred<T>, r: TempPred<T>, ex: Execution<T>)
    ensures q.satisfied_by(ex) ==> r.satisfied_by(ex),
{
    unimplemented!()
}

proof fn probe_h15<T>(q: TempPred<T>, r: TempPred<T>)
{
    assert forall |ex: Execution<T>| q.satisfied_by(ex) ==> r.satisfied_by(ex) by {
        let ex: Execution<T>;
        probe_bridge3(q, r, ex);
    }
}

#[verifier::external_body]
proof fn probe_bridge6(x: int)
    ensures probe_a(x) ==> probe_b(x),
{
    unimplemented!()
}

proof fn probe_h16()
{
    assert forall |x: int| probe_a(x) ==> probe_b(x) by {
        let x: int;
        probe_bridge6(x);
    }
}

pub closed spec fn probe_c(x: int, y: int) -> bool {
    x == y
}

pub closed spec fn probe_d(x: int, y: int) -> bool {
    x == y + 1
}

#[verifier::external_body]
proof fn probe_bridge8(x: int, y: int)
    requires probe_c(x, y),
    ensures probe_d(x, y),
{
    unimplemented!()
}

proof fn probe_h17(y: int)
{
    assert forall |x: int| probe_c(x, y) ==> probe_d(x, y) by {
        let x: int;
        if probe_c(x, y) {
            probe_bridge8(x, y);
        }
    }
}


}
