use vstd::prelude::*;
fn main() {}
verus! {

pub open spec fn set_fold<A, B>(s: Set<A>, zero: B, f: spec_fn(B, A) -> B) -> B
    recommends
        s.finite(),
    decreases s.len(),
{
    if s.finite() {
        if s.len() == 0 {
            zero
        } else {
            let a = s.choose();
            f(set_fold(s.remove(a), zero, f), a)
        }
    } else {
        zero
    }
}

spec fn map_fold<A, B>(s: Set<A>, f: spec_fn(A) -> B) -> Set<B>
    recommends
        s.finite(),
{
    set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
}

proof fn map_fold_ok<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
{
    map_fold_ok_helper(s, f);
}

proof fn map_fold_ok_helper<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
    decreases s.len(),
{
    let g = |s1: Set<B>, a: A| s1.insert(f(a));
    if s.len() == 0 {
        reveal(map_fold);
        s.lemma_len0_is_empty();
        assert(s =~= Set::<A>::empty());
        assert(map_fold(s, f) =~= Set::<B>::empty());
        assert(s.map(f) =~= Set::<B>::empty());
    } else {
        reveal(map_fold);
        let a = s.choose();
        let s2 = s.remove(a);
        assert(s.contains(a));
        assert(s2.finite());
        assert(s2.len() < s.len());
        assert(s =~= s2.insert(a));
        map_fold_ok_helper(s2, f);
        assert(set_fold(s, Set::<B>::empty(), g) =~= set_fold(s2, Set::<B>::empty(), g).insert(
            f(a),
        ));
        assert(map_fold(s, f) =~= map_fold(s2, f).insert(f(a)));
        assert(s.map(f) =~= s2.insert(a).map(f));
        assert(s2.insert(a).map(f) =~= s2.map(f).insert(f(a)));
        assert(map_fold(s, f) =~= s.map(f));
    }
}

} // verus!
