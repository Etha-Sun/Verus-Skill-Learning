use vstd::prelude::*;
fn main() {}
verus! {

pub open spec fn set_fold<A, B>(s: Set<A>, zero: B, f: spec_fn(B, A) -> B) -> B
    recommends
        s.finite(),
    decreases s.len(),
{
    if s.finite() {
        if s.len() == 0 {
            zero
        } else {
            let a = s.choose();
            f(set_fold(s.remove(a), zero, f), a)
        }
    } else {
        zero
    }
}

spec fn map_fold<A, B>(s: Set<A>, f: spec_fn(A) -> B) -> Set<B>
    recommends
        s.finite(),
{
    set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
}

proof fn map_fold_ok_helper<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
    decreases s.len(),
{
    if s.len() == 0 {
        assert(s =~= Set::empty());
        assert(set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a))) =~= Set::empty());
        assert(s.map(f) =~= Set::empty());
    } else {
        let a = s.choose();
        let rest = s.remove(a);
        map_fold_ok_helper::<A, B>(rest, f);
        assert(map_fold(rest, f) =~= rest.map(f));
        assert(s =~= rest.insert(a));
        assert(set_fold(s, Set::empty(), |s1: Set<B>, a2: A| s1.insert(f(a2)))
            =~= map_fold(rest, f).insert(f(a)));
        assert(s.map(f) =~= rest.map(f).insert(f(a)));
        assert(map_fold(s, f) =~= s.map(f));
    }
}

proof fn map_fold_ok<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
{
    map_fold_ok_helper::<A, B>(s, f);
}

} // verus!
