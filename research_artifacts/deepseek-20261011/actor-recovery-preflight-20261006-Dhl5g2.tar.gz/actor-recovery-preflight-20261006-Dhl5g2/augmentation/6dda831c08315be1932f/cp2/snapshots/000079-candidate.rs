use vstd::prelude::*;
fn main() {}
verus! {

pub open spec fn set_fold<A, B>(s: Set<A>, zero: B, f: spec_fn(B, A) -> B) -> B
    recommends
        s.finite(),
    decreases s.len(),
{
    if s.finite() {
        if s.len() == 0 {
            zero
        } else {
            let a = s.choose();
            f(set_fold(s.remove(a), zero, f), a)
        }
    } else {
        zero
    }
}

spec fn map_fold<A, B>(s: Set<A>, f: spec_fn(A) -> B) -> Set<B>
    recommends
        s.finite(),
{
    set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
}

proof fn map_fold_ok<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
{
    map_fold_ok_induct(s, f);
}

proof fn map_fold_ok_induct<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f) =~= s.map(f),
    decreases s.len(),
{
    if s.len() == 0 {
        assert(s.is_empty());
        assert(map_fold(s, f) =~= Set::empty());
        assert(s.map(f) =~= Set::empty());
    } else {
        let a = s.choose();
        assert(s.contains(a));
        let s2 = s.remove(a);
        assert(s2.finite());
        assert(s2.len() < s.len());
        map_fold_ok_induct(s2, f);
        assert(map_fold(s2, f) =~= s2.map(f));
        assert(map_fold(s, f) =~= map_fold(s2, f).insert(f(a)));
        assert(s2.insert(a) == s);
        assert(s.map(f) == (s2.insert(a)).map(f));
        assert forall|b: B| s2.map(f).insert(f(a)).contains(b) implies (s2.insert(a)).map(f).contains(
            b,
        ) by {
            if b == f(a) {
                assert(s2.insert(a).contains(a));
            } else {
                let y = choose|y: A| s2.contains(y) && f(y) == b;
                assert(y != a);
                assert(s2.insert(a).contains(y));
            }
        }
        assert((s2.insert(a)).map(f) =~= s2.map(f).insert(f(a)));
    }
}

} // verus!
