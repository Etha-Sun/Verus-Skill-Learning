use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn and(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) && other.satisfied_by(ex))
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn tla_exists<T, A>(a_to_temp_pred: spec_fn(A) -> TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| exists |a: A| #[trigger] a_to_temp_pred(a).satisfied_by(ex))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
spec fn tla_exists_choose_witness<T, A>(ex: Execution<T>, a_to_p: spec_fn(A) -> TempPred<T>) -> A
    recommends exists |a| #[trigger] a_to_p(a).satisfied_by(ex),
{
    let witness = choose |a| #[trigger] a_to_p(a).satisfied_by(ex);
    witness
}

	#[verifier::external_body]
proof fn tla_exists_proved_by_witness<T, A>(ex: Execution<T>, a_to_p: spec_fn(A) -> TempPred<T>, witness_a: A)
    requires a_to_p(witness_a).satisfied_by(ex),
    ensures tla_exists(a_to_p).satisfied_by(ex)
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn temp_pred_equality<T>(p: TempPred<T>, q: TempPred<T>)
    requires
        p.entails(q),
        q.entails(p),
    ensures p == q,
	{
		unimplemented!()
	}

proof fn tla_exists_and_equality<T, A>(a_to_p: spec_fn(A) -> TempPred<T>, q: TempPred<T>)
    ensures tla_exists(|a: A| a_to_p(a).and(q)) == tla_exists(a_to_p).and(q),
{
    let lhs = tla_exists(|a: A| a_to_p(a).and(q));
    let rhs = tla_exists(a_to_p).and(q);

    assert(lhs.entails(rhs)) by {
        assert forall |ex: Execution<T>| lhs.satisfied_by(ex) ==> rhs.satisfied_by(ex) by {
            if lhs.satisfied_by(ex) {
                let witness = tla_exists_choose_witness(ex, |a: A| a_to_p(a).and(q));
                assert((a_to_p(witness).and(q)).satisfied_by(ex));
                assert(a_to_p(witness).satisfied_by(ex));
                assert(q.satisfied_by(ex));
                tla_exists_proved_by_witness(ex, a_to_p, witness);
            }
        };
    };

    assert(rhs.entails(lhs)) by {
        assert forall |ex: Execution<T>| rhs.satisfied_by(ex) ==> lhs.satisfied_by(ex) by {
            if rhs.satisfied_by(ex) {
                let witness = tla_exists_choose_witness(ex, a_to_p);
                assert(a_to_p(witness).satisfied_by(ex));
                assert(q.satisfied_by(ex));
                assert((a_to_p(witness).and(q)).satisfied_by(ex));
                tla_exists_proved_by_witness(ex, |a: A| a_to_p(a).and(q), witness);
            }
        };
    };

    temp_pred_equality(lhs, rhs);
}


}
