use vstd::prelude::*;

fn main() {}

verus! {

use vstd::set::{
    axiom_set_ext_equal,
    axiom_set_new,
    axiom_set_remove_different,
    axiom_set_remove_same,
};

pub trait VerusClone: Sized {}

pub struct EndPoint {
    pub id: Vec<u8>,
}

type ID = EndPoint;

pub enum Ordering {
    Less,
    Equal,
    Greater,
}

impl Ordering {
    pub open spec fn lt(self) -> bool {
        matches!(self, Ordering::Less)
    }
}

pub trait KeyTrait: Sized {
    spec fn cmp_spec(self, other: Self) -> Ordering;
}

spec fn sorted<K: KeyTrait>(s: Seq<K>) -> bool {
    forall|i, j| #![auto] 0 <= i < j < s.len() ==> s[i].cmp_spec(s[j]).lt()
}

proof fn lemma_seq_remove_to_set<K>(s: Seq<K>, i: int)
    requires
        0 <= i < s.len(),
        s.no_duplicates(),
    ensures
        s.remove(i).to_set() == s.to_set().remove(s[i]),
{
    broadcast use vstd::set::group_set_axioms;

    assert forall|e: K| s.remove(i).to_set().contains(e) == s.to_set().remove(s[i]).contains(e) by {
        assert(s.remove(i).to_set().contains(e) ==> s.to_set().remove(s[i]).contains(e)) by {
            if s.remove(i).to_set().contains(e) {
                axiom_set_new(|a: K| s.remove(i).contains(a), e);
                assert(s.remove(i).contains(e));
                let j = s.remove(i).lemma_contains_to_index(e);
                s.remove_ensures(i);
                if j < i {
                    assert(s.remove(i)[j] == s[j]);
                    assert(s[j] == e);
                    assert(s.contains(e));
                    axiom_set_new(|a: K| s.contains(a), e);
                    assert(s.to_set().contains(e));
                    assert(e != s[i]) by {
                        assert(s[j] != s[i]);
                    }
                    axiom_set_remove_different(s.to_set(), e, s[i]);
                    assert(s.to_set().remove(s[i]).contains(e));
                } else {
                    assert(j < s.len() - 1);
                    assert(s.remove(i)[j] == s[j + 1]);
                    assert(s[j + 1] == e);
                    assert(s.contains(e));
                    axiom_set_new(|a: K| s.contains(a), e);
                    assert(s.to_set().contains(e));
                    assert(e != s[i]) by {
                        assert(s[j + 1] != s[i]);
                    }
                    axiom_set_remove_different(s.to_set(), e, s[i]);
                    assert(s.to_set().remove(s[i]).contains(e));
                }
            }
        };
        assert(s.to_set().remove(s[i]).contains(e) ==> s.remove(i).to_set().contains(e)) by {
            if s.to_set().remove(s[i]).contains(e) {
                axiom_set_remove_same(s.to_set(), s[i]);
                assert(e != s[i]);
                axiom_set_remove_different(s.to_set(), e, s[i]);
                assert(s.to_set().contains(e));
                axiom_set_new(|a: K| s.contains(a), e);
                assert(s.contains(e));
                let j = s.lemma_contains_to_index(e);
                s.remove_ensures(i);
                if j < i {
                    assert(s.remove(i)[j] == s[j]);
                    assert(s.remove(i)[j] == e);
                    assert(s.remove(i).contains(e));
                    axiom_set_new(|a: K| s.remove(i).contains(a), e);
                    assert(s.remove(i).to_set().contains(e));
                } else {
                    assert(j > i);
                    assert(i <= j - 1 < s.len() - 1);
                    assert(s.remove(i)[j - 1] == s[j]);
                    assert(s.remove(i)[j - 1] == e);
                    assert(s.remove(i).contains(e));
                    axiom_set_new(|a: K| s.remove(i).contains(a), e);
                    assert(s.remove(i).to_set().contains(e));
                }
            }
        };
    };
    axiom_set_ext_equal(s.remove(i).to_set(), s.to_set().remove(s[i]));
    assert(s.remove(i).to_set() == s.to_set().remove(s[i]));
}

struct StrictlyOrderedVec<K: KeyTrait> {
    v: Vec<K>,
}

impl<K: KeyTrait + VerusClone> StrictlyOrderedVec<K> {
    pub closed spec fn view(self) -> Seq<K> {
        self.v@
    }

    pub closed spec fn valid(self) -> bool {
        sorted(self@) && self@.no_duplicates()
    }

    fn remove(&mut self, i: usize) -> (k: K)
        requires
            old(self).valid(),
            i < old(self)@.len(),
        ensures
            self.valid(),
            k == old(self)@.index(i as int),
            self@ == old(self)@.remove(i as int),
            self@.to_set() == old(self)@.to_set().remove(k),
    {
        let k = self.v.remove(i);
        proof {
            let s = old(self)@;
            assert(s.no_duplicates()) by {
                reveal_with_fuel(StrictlyOrderedVec::valid, 1);
            }
            lemma_seq_remove_to_set::<K>(s, i as int);
            assert(self@.to_set() == s.to_set().remove(k));
        }
        k
    }
}

} // verus!
