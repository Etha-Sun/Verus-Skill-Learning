use vstd::prelude::*;

fn main() {}

verus! {

pub trait VerusClone: Sized {}

pub struct EndPoint {
    pub id: Vec<u8>,
}

type ID = EndPoint;

pub enum Ordering {
    Less,
    Equal,
    Greater,
}

impl Ordering {
    pub open spec fn lt(self) -> bool {
        matches!(self, Ordering::Less)
    }
}

pub trait KeyTrait: Sized {
    spec fn cmp_spec(self, other: Self) -> Ordering;
}

spec fn sorted<K: KeyTrait>(s: Seq<K>) -> bool {
    forall|i, j| #![auto] 0 <= i < j < s.len() ==> s[i].cmp_spec(s[j]).lt()
}

proof fn lemma_seq_remove_to_set<A>(s: Seq<A>, i: int)
    requires
        0 <= i < s.len(),
        s.no_duplicates(),
    ensures
        s.remove(i).to_set() == s.to_set().remove(s[i]),
{
    assert forall|x: A| #![auto]
        s.remove(i).to_set().contains(x) <==> s.to_set().remove(s[i]).contains(x)
        by
    {
        if s.remove(i).to_set().contains(x) {
            assert(s.remove(i).contains(x));
            let j = choose|j: int| 0 <= j < s.remove(i).len() && s.remove(i)[j] == x;
            s.remove_ensures(i);
            assert(s.remove(i).len() == s.len() - 1);
            if j < i {
                assert(s.remove(i)[j] == s[j]);
                assert(s[j] == x);
                assert(s.contains(x));
            } else {
                assert(s.remove(i)[j] == s[j + 1]);
                assert(s[j + 1] == x);
                assert(s.contains(x));
            }
            assert(x != s[i]) by {
                if x == s[i] {
                    if j < i {
                        assert(s[j] == s[i]);
                        assert(0 <= j < s.len() && j != i);
                        assert(s.no_duplicates());
                        assert(false);
                    } else {
                        assert(s[j + 1] == s[i]);
                        assert(0 <= j + 1 < s.len() && j + 1 != i);
                        assert(s.no_duplicates());
                        assert(false);
                    }
                }
            }
            assert(s.to_set().remove(s[i]).contains(x));
        }
        if s.to_set().remove(s[i]).contains(x) {
            assert(s.to_set().contains(x));
            assert(x != s[i]);
            assert(s.contains(x));
            let j = choose|j: int| 0 <= j < s.len() && s[j] == x;
            assert(j != i);
            s.remove_ensures(i);
            if j < i {
                assert(s.remove(i)[j] == s[j]);
                assert(s.remove(i).contains(x));
                assert(s.remove(i).to_set().contains(x));
            } else {
                assert(j - 1 >= i);
                assert(s.remove(i)[j - 1] == s[j]);
                assert(s.remove(i).contains(x));
                assert(s.remove(i).to_set().contains(x));
            }
        }
    };
    assert(s.remove(i).to_set() =~= s.to_set().remove(s[i]));
}

struct StrictlyOrderedVec<K: KeyTrait> {
    v: Vec<K>,
}

impl<K: KeyTrait + VerusClone> StrictlyOrderedVec<K> {
    pub closed spec fn view(self) -> Seq<K> {
        self.v@
    }

    pub closed spec fn valid(self) -> bool {
        sorted(self@) && self@.no_duplicates()
    }

    fn remove(&mut self, i: usize) -> (k: K)
        requires
            old(self).valid(),
            i < old(self)@.len(),
        ensures
            self.valid(),
            k == old(self)@.index(i as int),
            self@ == old(self)@.remove(i as int),
            self@.to_set() == old(self)@.to_set().remove(k),
    {
        let k = self.v.remove(i);
        proof {
            lemma_seq_remove_to_set(old(self)@, i as int);
            assert(self@ == old(self)@.remove(i as int));
            assert(k == old(self)@.index(i as int));
            assert(self@.to_set() == old(self)@.to_set().remove(k));
        }
        k
    }
}

} // verus!
