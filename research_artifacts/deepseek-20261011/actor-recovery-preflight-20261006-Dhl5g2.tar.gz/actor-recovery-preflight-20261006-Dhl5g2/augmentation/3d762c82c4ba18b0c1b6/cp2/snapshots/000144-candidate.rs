use vstd::prelude::*;

fn main() {}

verus! {

pub trait VerusClone: Sized {}

pub struct EndPoint {
    pub id: Vec<u8>,
}

type ID = EndPoint;

pub enum Ordering {
    Less,
    Equal,
    Greater,
}

impl Ordering {
    pub open spec fn lt(self) -> bool {
        matches!(self, Ordering::Less)
    }
}

pub trait KeyTrait: Sized {
    spec fn cmp_spec(self, other: Self) -> Ordering;
}

spec fn sorted<K: KeyTrait>(s: Seq<K>) -> bool {
    forall|i, j| #![auto] 0 <= i < j < s.len() ==> s[i].cmp_spec(s[j]).lt()
}

proof fn lemma_remove_to_set<K>(s: Seq<K>, i: int)
    requires
        0 <= i < s.len(),
        s.no_duplicates(),
    ensures
        s.remove(i).to_set() == s.to_set().remove(s.index(i)),
{
    vstd::assert_sets_equal!(s.remove(i).to_set() == s.to_set().remove(s.index(i)), e => {
        if s.remove(i).to_set().contains(e) {
            let t = s.remove(i);
            assert(t.contains(e));
            let j = choose|j: int| 0 <= j < t.len() && t[j] == e;
            assert(0 <= j < t.len() && t[j] == e);
            if j < i {
                assert(t[j] == s[j]);
                assert(s[j] == e);
                assert(s.to_set().contains(e));
                assert(e != s.index(i)) by {
                    assert(j != i);
                    assert(s[j] != s.index(i));
                }
                vstd::set::axiom_set_remove_different(s.to_set(), e, s.index(i));
                assert(s.to_set().remove(s.index(i)).contains(e));
            } else {
                assert(t[j] == s[j + 1]);
                assert(s[j + 1] == e);
                assert(s.to_set().contains(e));
                assert(e != s.index(i)) by {
                    assert(j + 1 != i);
                    assert(s[j + 1] != s.index(i));
                }
                vstd::set::axiom_set_remove_different(s.to_set(), e, s.index(i));
                assert(s.to_set().remove(s.index(i)).contains(e));
            }
        } else {
            if s.to_set().remove(s.index(i)).contains(e) {
                if e == s.index(i) {
                    vstd::set::axiom_set_remove_same(s.to_set(), s.index(i));
                    assert(!s.to_set().remove(s.index(i)).contains(e));
                    assert(false);
                }
                assert(e != s.index(i));
                vstd::set::axiom_set_remove_different(s.to_set(), e, s.index(i));
                assert(s.to_set().contains(e));
                let k = choose|k: int| 0 <= k < s.len() && s[k] == e;
                assert(0 <= k < s.len() && s[k] == e);
                if k < i {
                    assert(s.remove(i)[k] == s[k]);
                    assert(s.remove(i).contains(e));
                    assert(s.remove(i).to_set().contains(e));
                } else if k == i {
                    assert(s.index(i) == e);
                    assert(false);
                } else {
                    assert(s.remove(i)[k - 1] == s[k]);
                    assert(s.remove(i).contains(e));
                    assert(s.remove(i).to_set().contains(e));
                }
            }
        }
    });
}

struct StrictlyOrderedVec<K: KeyTrait> {
    v: Vec<K>,
}

impl<K: KeyTrait + VerusClone> StrictlyOrderedVec<K> {
    pub closed spec fn view(self) -> Seq<K> {
        self.v@
    }

    pub closed spec fn valid(self) -> bool {
        sorted(self@) && self@.no_duplicates()
    }

    fn remove(&mut self, i: usize) -> (k: K)
        requires
            old(self).valid(),
            i < old(self)@.len(),
        ensures
            self.valid(),
            k == old(self)@.index(i as int),
            self@ == old(self)@.remove(i as int),
            self@.to_set() == old(self)@.to_set().remove(k),
    {
        let k = self.v.remove(i);
        proof {
            let s = old(self)@;
            assert(k == s.index(i as int));
            lemma_remove_to_set::<K>(s, i as int);
            assert(self@ == s.remove(i as int));
            assert(self@.to_set() == old(self)@.to_set().remove(k));
        }
        k
    }
}

} // verus!
