use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn and(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) && other.satisfied_by(ex))
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn leads_to(self, other: Self) -> Self {
        always(self.implies(eventually(other)))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn eventually<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| exists |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn later<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| temp_pred.satisfied_by(ex.suffix(1)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn leads_to_unfold<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires p.leads_to(q).satisfied_by(ex),
    ensures forall |i: nat| p.implies(eventually(q)).satisfied_by(#[trigger] ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn always_propagate_forwards<T>(ex: Execution<T>, p: TempPred<T>, i: nat)
    requires always(p).satisfied_by(ex),
    ensures always(p).satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn eventually_proved_by_witness<T>(ex: Execution<T>, p: TempPred<T>, witness_idx: nat)
    requires p.satisfied_by(ex.suffix(witness_idx)),
    ensures eventually(p).satisfied_by(ex)
	{
		unimplemented!()
	}

spec fn eventually_choose_witness<T>(ex: Execution<T>, p: TempPred<T>) -> nat
    recommends exists |i| p.satisfied_by(#[trigger] ex.suffix(i)),
{
    let witness = choose |i| p.satisfied_by(#[trigger] ex.suffix(i));
    witness
}

	#[verifier::external_body]
proof fn next_preserves_inv_rec<T>(ex: Execution<T>, next: TempPred<T>, inv: TempPred<T>, i: nat)
    requires
        inv.satisfied_by(ex),
        forall |idx| next.satisfied_by(#[trigger] ex.suffix(idx)),
        forall |idx| inv.satisfied_by(#[trigger] ex.suffix(idx)) && next.satisfied_by(ex.suffix(idx))
            ==> inv.satisfied_by(ex.suffix(idx + 1)),
    ensures inv.satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn suffix_comp<T>(ex: Execution<T>, a: nat, b: nat)
    ensures ex.suffix(a).suffix(b) == ex.suffix(a + b),
{
    assert forall |i: nat| #[trigger] (ex.suffix(a).suffix(b).nat_to_state)(i)
        == (ex.suffix(a + b).nat_to_state)(i) by {
        assert((ex.suffix(a).suffix(b).nat_to_state)(i) == (ex.suffix(a).nat_to_state)(i + b));
        assert((ex.suffix(a).nat_to_state)(i + b) == (ex.nat_to_state)((i + b) + a));
        assert((ex.suffix(a + b).nat_to_state)(i) == (ex.nat_to_state)(i + (a + b)));
        assert((i + b) + a == i + (a + b));
    }
    execution_equality(ex.suffix(a).suffix(b), ex.suffix(a + b));
}

proof fn q_persists<T>(spec: TempPred<T>, next: TempPred<T>, q: TempPred<T>, ex: Execution<T>, t: nat)
    requires
        spec.satisfied_by(ex),
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        q.satisfied_by(ex.suffix(t)),
    ensures always(q).satisfied_by(ex.suffix(t)),
{
    implies_apply(ex, spec, always(q.and(next).implies(later(q))));
    implies_apply(ex, spec, always(next));
    always_propagate_forwards(ex, q.and(next).implies(later(q)), t);
    always_propagate_forwards(ex, next, t);

    assert forall |idx: nat| q.satisfied_by(#[trigger] ex.suffix(t).suffix(idx))
        && next.satisfied_by(ex.suffix(t).suffix(idx))
        ==> q.satisfied_by(ex.suffix(t).suffix(idx + 1)) by {
        if q.satisfied_by(ex.suffix(t).suffix(idx)) && next.satisfied_by(ex.suffix(t).suffix(idx)) {
            implies_apply(ex.suffix(t).suffix(idx), q.and(next), later(q));
            suffix_comp(ex.suffix(t), idx, 1);
        }
    }

    assert forall |j: nat| #[trigger] q.satisfied_by(ex.suffix(t).suffix(j)) by {
        next_preserves_inv_rec(ex.suffix(t), next, q, j);
    }

    assert(always(q).satisfied_by(ex.suffix(t)));
}

pub proof fn leads_to_stable<T>(spec: TempPred<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(p.leads_to(q)),
    ensures spec.entails(p.leads_to(always(q))),
{
    assert forall |ex: Execution<T>| #[trigger] spec.satisfied_by(ex) ==>
        p.leads_to(always(q)).satisfied_by(ex) by {
        if spec.satisfied_by(ex) {
            implies_apply(ex, spec, p.leads_to(q));
            assert forall |i: nat| #[trigger] p.implies(eventually(always(q))).satisfied_by(ex.suffix(i)) by {
                if p.satisfied_by(ex.suffix(i)) {
                    leads_to_unfold(ex, p, q);
                    implies_apply(ex.suffix(i), p, eventually(q));
                    let w = eventually_choose_witness(ex.suffix(i), q);
                    assert(q.satisfied_by(ex.suffix(i).suffix(w)));
                    suffix_comp(ex, i, w);
                    assert(q.satisfied_by(ex.suffix(i + w)));
                    q_persists(spec, next, q, ex, i + w);
                    eventually_proved_by_witness(ex.suffix(i), always(q), w);
                }
            }
            assert(p.leads_to(always(q)).satisfied_by(ex));
        }
    }
}


}
