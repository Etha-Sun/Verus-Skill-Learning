use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn and(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) && other.satisfied_by(ex))
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn leads_to(self, other: Self) -> Self {
        always(self.implies(eventually(other)))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn eventually<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| exists |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn later<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| temp_pred.satisfied_by(ex.suffix(1)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn leads_to_unfold<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires p.leads_to(q).satisfied_by(ex),
    ensures forall |i: nat| p.implies(eventually(q)).satisfied_by(#[trigger] ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn always_propagate_forwards<T>(ex: Execution<T>, p: TempPred<T>, i: nat)
    requires always(p).satisfied_by(ex),
    ensures always(p).satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn eventually_proved_by_witness<T>(ex: Execution<T>, p: TempPred<T>, witness_idx: nat)
    requires p.satisfied_by(ex.suffix(witness_idx)),
    ensures eventually(p).satisfied_by(ex)
	{
		unimplemented!()
	}

spec fn eventually_choose_witness<T>(ex: Execution<T>, p: TempPred<T>) -> nat
    recommends exists |i| p.satisfied_by(#[trigger] ex.suffix(i)),
{
    let witness = choose |i| p.satisfied_by(#[trigger] ex.suffix(i));
    witness
}

	#[verifier::external_body]
proof fn next_preserves_inv_rec<T>(ex: Execution<T>, next: TempPred<T>, inv: TempPred<T>, i: nat)
    requires
        inv.satisfied_by(ex),
        forall |idx| next.satisfied_by(#[trigger] ex.suffix(idx)),
        forall |idx| inv.satisfied_by(#[trigger] ex.suffix(idx)) && next.satisfied_by(ex.suffix(idx))
            ==> inv.satisfied_by(ex.suffix(idx + 1)),
    ensures inv.satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

proof fn entails_apply<T>(spec: TempPred<T>, phi: TempPred<T>, ex: Execution<T>)
    requires
        spec.entails(phi),
        spec.satisfied_by(ex),
    ensures phi.satisfied_by(ex),
{
    assert(spec.implies(phi).satisfied_by(ex));
    implies_apply::<T>(ex, spec, phi);
}

proof fn suffix_shift<T>(ex: Execution<T>, i: nat, j: nat)
    ensures ex.suffix(i).suffix(j) == ex.suffix(i + j),
{
    assert forall |n: nat| #[trigger] ((ex.suffix(i).suffix(j)).nat_to_state)(n) == ((ex.suffix(i + j)).nat_to_state)(n) by {
        assert(((ex.suffix(i).suffix(j)).nat_to_state)(n) == ((ex.suffix(i + j)).nat_to_state)(n));
    };
    execution_equality::<T>(ex.suffix(i).suffix(j), ex.suffix(i + j));
}

proof fn q_forward<T>(base: Execution<T>, next: TempPred<T>, q: TempPred<T>, k: nat, n: nat)
    requires
        q.satisfied_by(base.suffix(k)),
        forall |idx| next.satisfied_by(#[trigger] base.suffix(idx)),
        forall |idx| (q.satisfied_by(#[trigger] base.suffix(idx)) && next.satisfied_by(base.suffix(idx)))
            ==> q.satisfied_by(base.suffix(idx).suffix(1)),
    ensures q.satisfied_by(base.suffix(k + n)),
    decreases n,
{
    if n == 0 {
        assert(q.satisfied_by(base.suffix(k + n)));
    } else {
        q_forward::<T>(base, next, q, k, ((n - 1) as nat));
        let idx = k + ((n - 1) as nat);
        assert(q.satisfied_by(base.suffix(idx)));
        assert(next.satisfied_by(base.suffix(idx)));
        assert(q.satisfied_by(base.suffix(idx).suffix(1)));
        suffix_shift::<T>(base, idx, 1);
        assert forall |m: nat| #[trigger] ((base.suffix(idx + 1)).nat_to_state)(m) == ((base.suffix(k + n)).nat_to_state)(m) by {
            assert(((base.suffix(idx + 1)).nat_to_state)(m) == ((base.suffix(k + n)).nat_to_state)(m));
        };
        execution_equality::<T>(base.suffix(idx + 1), base.suffix(k + n));
        assert(q.satisfied_by(base.suffix(k + n)));
    }
}

proof fn stability_from_witness<T>(spec: TempPred<T>, next: TempPred<T>, q: TempPred<T>, ex: Execution<T>, i: nat, k: nat)
    requires
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        spec.satisfied_by(ex),
        q.satisfied_by(ex.suffix(i).suffix(k)),
    ensures always(q).satisfied_by(ex.suffix(i).suffix(k)),
{
    entails_apply::<T>(spec, always(q.and(next).implies(later(q))), ex);
    entails_apply::<T>(spec, always(next), ex);
    always_propagate_forwards::<T>(ex, q.and(next).implies(later(q)), i);
    always_propagate_forwards::<T>(ex, next, i);

    assert forall |idx| (q.satisfied_by(#[trigger] ex.suffix(i).suffix(idx)) && next.satisfied_by(ex.suffix(i).suffix(idx)))
        ==> q.satisfied_by(ex.suffix(i).suffix(idx).suffix(1));
    assert forall |idx| next.satisfied_by(#[trigger] ex.suffix(i).suffix(idx));

    assert forall |n: nat| q.satisfied_by(#[trigger] ex.suffix(i).suffix(k).suffix(n)) by {
        q_forward::<T>(ex.suffix(i), next, q, k, n);
        suffix_shift::<T>(ex.suffix(i), k, n);
        assert(q.satisfied_by(ex.suffix(i).suffix(k).suffix(n)));
    }
}

proof fn lead_to_always_at<T>(spec: TempPred<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>, ex: Execution<T>, i: nat)
    requires
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(p.leads_to(q)),
        spec.satisfied_by(ex),
        p.satisfied_by(ex.suffix(i)),
    ensures eventually(always(q)).satisfied_by(ex.suffix(i)),
{
    entails_apply::<T>(spec, p.leads_to(q), ex);
    leads_to_unfold::<T>(ex, p, q);
    assert(p.implies(eventually(q)).satisfied_by(ex.suffix(i)));
    implies_apply::<T>(ex.suffix(i), p, eventually(q));
    let k = eventually_choose_witness::<T>(ex.suffix(i), q);
    stability_from_witness::<T>(spec, next, q, ex, i, k);
    eventually_proved_by_witness::<T>(ex.suffix(i), always(q), k);
}

proof fn lemma_leads_to_stable_instance<T>(spec: TempPred<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>, ex: Execution<T>)
    requires
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(p.leads_to(q)),
        spec.satisfied_by(ex),
    ensures p.leads_to(always(q)).satisfied_by(ex),
{
    assert forall |i: nat| p.implies(eventually(always(q))).satisfied_by(#[trigger] ex.suffix(i)) by {
        if p.satisfied_by(ex.suffix(i)) {
            lead_to_always_at::<T>(spec, next, p, q, ex, i);
            assert(eventually(always(q)).satisfied_by(ex.suffix(i)));
        }
    }
}

pub proof fn leads_to_stable<T>(spec: TempPred<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        spec.entails(always(q.and(next).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(p.leads_to(q)),
    ensures spec.entails(p.leads_to(always(q))),
{
    assert forall |ex: Execution<T>| spec.implies(p.leads_to(always(q))).satisfied_by(ex) by {
        if spec.satisfied_by(ex) {
            lemma_leads_to_stable_instance::<T>(spec, next, p, q, ex);
            assert(p.leads_to(always(q)).satisfied_by(ex));
        }
    }
}


}
