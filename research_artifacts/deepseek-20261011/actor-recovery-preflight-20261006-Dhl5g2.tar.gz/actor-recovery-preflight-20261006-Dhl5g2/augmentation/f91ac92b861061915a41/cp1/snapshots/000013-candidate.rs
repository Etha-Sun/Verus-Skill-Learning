use vstd::prelude::*;

fn main() {}

verus!{


pub proof fn seq_equal_preserved_by_add<A>(s1: Seq<A>, s2: Seq<A>, suffix: Seq<A>)
    ensures s1 == s2 <==> s1 + suffix == s2 + suffix
{
    assert(s1 == s2 ==> s1 + suffix == s2 + suffix) by {
        if s1 == s2 {
            assert(s1.len() == s2.len());
            vstd::assert_seqs_equal!(s1 + suffix, s2 + suffix, i => {
                if i < s1.len() {
                    assert((s1 + suffix)[i] == s1[i]);
                    assert((s2 + suffix)[i] == s2[i]);
                } else {
                    assert((s1 + suffix)[i] == suffix[i - s1.len()]);
                    assert((s2 + suffix)[i] == suffix[i - s2.len()]);
                }
            });
        }
    }
    assert(s1 + suffix == s2 + suffix ==> s1 == s2) by {
        if s1 + suffix == s2 + suffix {
            assert(s1.len() == s2.len());
            vstd::assert_seqs_equal!(s1, s2, i => {
                assert((s1 + suffix)[i] == s1[i]);
                assert((s2 + suffix)[i] == s2[i]);
            });
        }
    }
}

}
