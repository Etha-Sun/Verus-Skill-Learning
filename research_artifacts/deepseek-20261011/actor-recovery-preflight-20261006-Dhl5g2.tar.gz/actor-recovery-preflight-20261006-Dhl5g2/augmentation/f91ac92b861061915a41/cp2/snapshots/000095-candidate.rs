use vstd::prelude::*;

fn main() {}

verus!{


pub proof fn seq_equal_preserved_by_add<A>(s1: Seq<A>, s2: Seq<A>, suffix: Seq<A>)
    ensures s1 == s2 <==> s1 + suffix == s2 + suffix
{
    if s1 == s2 {
        vstd::assert_seqs_equal!(s1 + suffix == s2 + suffix);
    }
    if s1 + suffix == s2 + suffix {
        assert((s1 + suffix).len() == (s2 + suffix).len());
        assert(s1.len() == s2.len());
        assert forall |idx: int| 0 <= idx < s1.len() ==> #[trigger] s1[idx] == #[trigger] s2[idx] by {
            assert((s1 + suffix)[idx] == s1[idx]);
            assert((s2 + suffix)[idx] == s2[idx]);
            assert((s1 + suffix)[idx] == (s2 + suffix)[idx]);
        };
        vstd::assert_seqs_equal!(s1 == s2);
    }
}

}
