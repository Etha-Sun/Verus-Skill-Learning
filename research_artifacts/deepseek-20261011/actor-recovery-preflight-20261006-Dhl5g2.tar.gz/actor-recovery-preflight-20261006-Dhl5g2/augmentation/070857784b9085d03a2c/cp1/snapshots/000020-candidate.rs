use vstd::prelude::*;
fn main() {}
verus! {

pub open spec fn set_fold<A, B>(s: Set<A>, zero: B, f: spec_fn(B, A) -> B) -> B
    recommends
        s.finite(),
    decreases s.len(),
{
    if s.finite() {
        if s.len() == 0 {
            zero
        } else {
            let a = s.choose();
            f(set_fold(s.remove(a), zero, f), a)
        }
    } else {
        zero
    }
}

spec fn map_fold<A, B>(s: Set<A>, f: spec_fn(A) -> B) -> Set<B>
    recommends
        s.finite(),
{
    set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
}

proof fn map_fold_finite<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f).finite(),
{
    reveal_with_fuel(map_fold, 2);
    map_fold_finite_impl::<A, B>(s, f);
}

proof fn map_fold_finite_impl<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        set_fold(s, Set::<B>::empty(), |s1: Set<B>, a: A| s1.insert(f(a))).finite(),
    decreases s.len(),
{
    if s.len() == 0 {
        assert(
            set_fold(s, Set::<B>::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
                == Set::<B>::empty()
        );
    } else {
        let a = s.choose();
        let s_rem = s.remove(a);
        map_fold_finite_impl::<A, B>(s_rem, f);
        assert(
            set_fold(s, Set::<B>::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
                == set_fold(s_rem, Set::<B>::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
                    .insert(f(a))
        );
    }
}

} // verus!
