use vstd::prelude::*;
fn main() {}
verus! {

pub open spec fn set_fold<A, B>(s: Set<A>, zero: B, f: spec_fn(B, A) -> B) -> B
    recommends
        s.finite(),
    decreases s.len(),
{
    if s.finite() {
        if s.len() == 0 {
            zero
        } else {
            let a = s.choose();
            f(set_fold(s.remove(a), zero, f), a)
        }
    } else {
        zero
    }
}

spec fn map_fold<A, B>(s: Set<A>, f: spec_fn(A) -> B) -> Set<B>
    recommends
        s.finite(),
{
    set_fold(s, Set::empty(), |s1: Set<B>, a: A| s1.insert(f(a)))
}

proof fn map_fold_finite_helper<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f).finite(),
    decreases s.len(),
{
    if s.len() == 0 {
        assert(map_fold(s, f) === Set::<B>::empty());
        assert(map_fold(s, f).finite());
    } else {
        let a = s.choose();
        assert(s.remove(a).len() < s.len());
        map_fold_finite_helper(s.remove(a), f);
        assert(map_fold(s, f) === map_fold(s.remove(a), f).insert(f(a)));
        assert(map_fold(s.remove(a), f).insert(f(a)).finite());
        assert(map_fold(s, f).finite());
    }
}

proof fn map_fold_finite<A, B>(s: Set<A>, f: spec_fn(A) -> B)
    requires
        s.finite(),
    ensures
        map_fold(s, f).finite(),
{
    map_fold_finite_helper(s, f);
}

} // verus!
