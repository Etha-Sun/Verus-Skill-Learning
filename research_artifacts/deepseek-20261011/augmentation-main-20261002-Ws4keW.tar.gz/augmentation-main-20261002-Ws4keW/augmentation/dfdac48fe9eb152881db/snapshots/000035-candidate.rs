use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn and(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) && other.satisfied_by(ex))
    }

    pub open spec fn or(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) || other.satisfied_by(ex))
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn leads_to(self, other: Self) -> Self {
        always(self.implies(eventually(other)))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn eventually<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| exists |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn later<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| temp_pred.satisfied_by(ex.suffix(1)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn leads_to_unfold<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires p.leads_to(q).satisfied_by(ex),
    ensures forall |i: nat| p.implies(eventually(q)).satisfied_by(#[trigger] ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn always_propagate_forwards<T>(ex: Execution<T>, p: TempPred<T>, i: nat)
    requires always(p).satisfied_by(ex),
    ensures always(p).satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn eventually_proved_by_witness<T>(ex: Execution<T>, p: TempPred<T>, witness_idx: nat)
    requires p.satisfied_by(ex.suffix(witness_idx)),
    ensures eventually(p).satisfied_by(ex)
	{
		unimplemented!()
	}

spec fn eventually_choose_witness<T>(ex: Execution<T>, p: TempPred<T>) -> nat
    recommends exists |i| p.satisfied_by(#[trigger] ex.suffix(i)),
{
    let witness = choose |i| p.satisfied_by(#[trigger] ex.suffix(i));
    witness
}

	#[verifier::external_body]
proof fn always_p_or_eventually_q<T>(ex: Execution<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        always(p.and(next).implies(later(p).or(later(q)))).satisfied_by(ex),
        always(next).satisfied_by(ex),
    ensures always(p.implies(always(p).or(eventually(q)))).satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn wf1_variant_temp<T>(spec: TempPred<T>, next: TempPred<T>, forward: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        spec.entails(always(p.and(next).implies(later(p).or(later(q))))),
        spec.entails(always(p.and(next).and(forward).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(always(p).leads_to(forward)),
    ensures spec.entails(p.leads_to(q)),
{
    assert forall |ex: Execution<T>| #[trigger] spec.implies(p.leads_to(q)).satisfied_by(ex) by {
        if spec.satisfied_by(ex) {
            assert(p.leads_to(q).satisfied_by(ex)) by {
                assert forall |i: nat| #[trigger] p.implies(eventually(q)).satisfied_by(ex.suffix(i)) by {
                    if p.satisfied_by(ex.suffix(i)) {
                        leads_to_q_at::<T>(spec, next, forward, p, q, ex, i);
                    }
                };
            };
        }
    };
}


pub open spec fn choose_eventually_witness<T>(ex: Execution<T>, p: TempPred<T>) -> nat
{
    choose |i: nat| p.satisfied_by(#[trigger] ex.suffix(i))
}

pub proof fn entails_at<T>(spec: TempPred<T>, x: TempPred<T>, ex: Execution<T>)
    requires spec.entails(x),
    ensures spec.implies(x).satisfied_by(ex),
{
}

pub proof fn always_at<T>(p: TempPred<T>, ex: Execution<T>, i: nat)
    requires always(p).satisfied_by(ex),
    ensures p.satisfied_by(ex.suffix(i)),
{
}

pub proof fn suffix_shift<T>(ex: Execution<T>, i: nat, d: nat)
    ensures (ex.suffix(i)).suffix(d) == ex.suffix(i + d),
{
    assert forall |k: nat| #[trigger] (((ex.suffix(i)).suffix(d)).nat_to_state)(k) == ((ex.suffix(i + d)).nat_to_state)(k) by {
        assert((((ex.suffix(i)).suffix(d)).nat_to_state)(k) == (ex.nat_to_state)(k + d + i));
        assert(((ex.suffix(i + d)).nat_to_state)(k) == (ex.nat_to_state)(k + (i + d)));
    };
    execution_equality::<T>((ex.suffix(i)).suffix(d), ex.suffix(i + d));
}

pub proof fn leads_to_q_at<T>(spec: TempPred<T>, next: TempPred<T>, forward: TempPred<T>, p: TempPred<T>, q: TempPred<T>, ex: Execution<T>, i: nat)
    requires
        spec.entails(always(p.and(next).implies(later(p).or(later(q))))),
        spec.entails(always(p.and(next).and(forward).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(always(p).leads_to(forward)),
        spec.satisfied_by(ex),
        p.satisfied_by(ex.suffix(i)),
    ensures eventually(q).satisfied_by(ex.suffix(i)),
{
    let s1 = entails_at::<T>(spec, always(p.and(next).implies(later(p).or(later(q)))), ex);
    let a1 = implies_apply::<T>(ex, spec, always(p.and(next).implies(later(p).or(later(q)))));
    let s3 = entails_at::<T>(spec, always(next), ex);
    let a3 = implies_apply::<T>(ex, spec, always(next));
    let s2 = entails_at::<T>(spec, always(p.and(next).and(forward).implies(later(q))), ex);
    let a2 = implies_apply::<T>(ex, spec, always(p.and(next).and(forward).implies(later(q))));
    let s4 = entails_at::<T>(spec, always(p).leads_to(forward), ex);
    let r4 = implies_apply::<T>(ex, spec, always(p).leads_to(forward));

    let h_or = always_p_or_eventually_q::<T>(ex, next, p, q);
    let h_or_at_i = always_at::<T>(p.implies(always(p).or(eventually(q))), ex, i);
    let disj = implies_apply::<T>(ex.suffix(i), p, always(p).or(eventually(q)));

    assert(eventually(q).satisfied_by(ex.suffix(i))) by {
        if always(p).satisfied_by(ex.suffix(i)) {
            let lunf = leads_to_unfold::<T>(ex, always(p), forward);
            assert(always(p).implies(eventually(forward)).satisfied_by(ex.suffix(i))) by {
            }
            let ef = implies_apply::<T>(ex.suffix(i), always(p), eventually(forward));

            let d = choose_eventually_witness::<T>(ex.suffix(i), forward);
            assert(forward.satisfied_by((ex.suffix(i)).suffix(d))) by {
            }

            let p_mid = always_at::<T>(p, ex.suffix(i), d);
            let n_fwd = always_propagate_forwards::<T>(ex, next, i);
            let n_mid = always_at::<T>(next, ex.suffix(i), d);

            let r2_impl = (p.and(next).and(forward)).implies(later(q));
            let r2_fwd = always_propagate_forwards::<T>(ex, r2_impl, i);
            let r2_at = always_at::<T>(r2_impl, ex.suffix(i), d);
            let lq = implies_apply::<T>((ex.suffix(i)).suffix(d), p.and(next).and(forward), later(q));

            assert(q.satisfied_by(((ex.suffix(i)).suffix(d)).suffix(1))) by {
            }
            let sh = suffix_shift::<T>(ex.suffix(i), d, 1);
            assert(q.satisfied_by((ex.suffix(i)).suffix(d + 1))) by {
            }

            let efin = eventually_proved_by_witness::<T>(ex.suffix(i), q, d + 1);
            assert(eventually(q).satisfied_by(ex.suffix(i))) by {
            }
        } else {
            assert(eventually(q).satisfied_by(ex.suffix(i))) by {
            }
        }
    };
}


}
