extern crate verus_builtin_macros as builtin_macros;
use std::collections;
use vstd::bytes::*;
use vstd::prelude::*;
fn main() {}
verus! {

#[verifier(external_body)]
pub struct CKeyHashMap {
    m: collections::HashMap<CKey, Vec<u8>>,
}

impl CKeyHashMap {
    pub uninterp spec fn view(self) -> Map<AbstractKey, Seq<u8>>;

    pub uninterp spec fn spec_to_vec(&self) -> Vec<CKeyKV>;

    #[verifier(external_body)]
    #[verifier(when_used_as_spec(spec_to_vec))]
    pub fn to_vec(&self) -> (res: Vec<CKeyKV>) {
        unimplemented!()
    }

    pub uninterp spec fn spec_from_vec(v: Vec<CKeyKV>) -> Self;

    #[verifier::external_body]
    pub proof fn lemma_to_vec(self)
        ensures
            Self::spec_from_vec(self.spec_to_vec()) == self,
            self.spec_to_vec().len() == self@.dom().len(),
            spec_sorted_keys(self.spec_to_vec()),
            (forall|i: int|
                #![trigger(self.spec_to_vec() [i])]
                0 <= i < self.spec_to_vec().len() ==> {
                    let (k, v) = self.spec_to_vec()[i]@;
                    self@.contains_pair(k, v)
                }),
    {
        unimplemented!()
    }
}

pub struct CKeyKV {
    pub k: CKey,
    pub v: Vec<u8>,
}

impl CKeyKV {
    pub open spec fn view(self) -> (AbstractKey, Seq<u8>) {
        (self.k, self.v@)
    }
}

pub open spec fn ckeykvlt(a: CKeyKV, b: CKeyKV) -> bool {
    a.k.ukey < b.k.ukey
}

pub open spec fn spec_sorted_keys(v: Vec<CKeyKV>) -> bool {
    forall|i: int, j: int|
        0 <= i && i + 1 < v.len() && j == i + 1 ==> #[trigger] ckeykvlt(v@[i], v@[j])
}

#[derive(Eq, PartialEq, Hash)]
pub struct SHTKey {
    pub ukey: u64,
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_append_len_int<A, B>(
    s: Seq<A>,
    prefix: Seq<B>,
    f: spec_fn(A) -> Seq<B>,
)
    ensures
        s.fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a)).len() as int == s.fold_left(
            prefix.len() as int,
            |i: int, a: A| i + f(a).len() as int,
        ),
    decreases s.len(),
{
    unimplemented!()
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_sum_le<A>(s: Seq<A>, init: int, high: int, f: spec_fn(A) -> int)
    requires
        forall|i: int| 0 <= i < s.len() ==> f(s[i]) <= high,
    ensures
        s.fold_left(init, |acc: int, x: A| acc + f(x)) <= init + s.len() * high,
    decreases s.len(),
{
    unimplemented!()
}

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }
}

impl Marshalable for usize {
    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }
}

impl<T: Marshalable, U: Marshalable> Marshalable for (T, U) {
    open spec fn is_marshalable(&self) -> bool {
        &&& self.0.is_marshalable()
        &&& self.1.is_marshalable()
        &&& self.0.ghost_serialize().len() + self.1.ghost_serialize().len() <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.0.ghost_serialize() + self.1.ghost_serialize()
    }
}

macro_rules! derive_marshalable_for_struct { { $(#[$attr :
    meta])* $pub : vis struct $newstruct : ident $(< $($poly : ident : Marshalable),+
    $(,)? >)? { $($fieldvis : vis $field : ident : $fieldty : ty),+ $(,)? } } => {
    ::builtin_macros::verus! { impl $(< $($poly : Marshalable),* >)? Marshalable for
    $newstruct $(< $($poly),* >)? { open spec fn is_marshalable(& self) -> bool { $(&&&
    self.$field .is_marshalable())* &&& 0 $(+ self.$field .ghost_serialize().len())* <=
    usize::MAX } open spec fn ghost_serialize(& self) -> Seq < u8 > { Seq::empty() $(+
    self.$field .ghost_serialize())* } } } } }

macro_rules! marshalable_by_bijection { {
    [$type : ty] <-> [$marshalable : ty]; forward($self : ident) $forward : expr;
    backward($m : ident) $backward : expr; } => { ::builtin_macros::verus! { impl $type {
    pub open spec fn
    forward_bijection_for_view_equality_do_not_use_for_anything_else($self : Self) ->
    $marshalable { $forward } } impl Marshalable for $type { open spec fn
    is_marshalable($self : & Self) -> bool { $forward .is_marshalable() } open spec fn
    ghost_serialize($self : & Self) -> Seq < u8 > { $forward .ghost_serialize() } } } } }

#[verifier::opaque]
pub open spec fn ckeyhashmap_max_serialized_size() -> usize {
    0x100000
}

impl Marshalable for CKeyHashMap {
    open spec fn is_marshalable(&self) -> bool {
        self.to_vec().is_marshalable() && spec_sorted_keys(self.to_vec())
            && self.to_vec().ghost_serialize().len() <= (ckeyhashmap_max_serialized_size() as int)
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.to_vec().ghost_serialize()
    }
}

pub open spec fn max_val_len() -> int {
    1024
}

pub open spec fn valid_key(key: AbstractKey) -> bool {
    true
}

pub open spec fn valid_value(value: AbstractValue) -> bool {
    value.len() < max_val_len()
}

pub open spec fn max_hashtable_size() -> int {
    62
}

pub open spec fn valid_hashtable(h: Hashtable) -> bool {
    &&& h.dom().len() < max_hashtable_size()
    &&& (forall|k| h.dom().contains(k) ==> valid_key(k) && #[trigger] valid_value(h[k]))
}

pub type CKey = SHTKey;

pub type AbstractKey = SHTKey;

pub type AbstractValue = Seq<u8>;

pub type Hashtable = Map<AbstractKey, AbstractValue>;

marshalable_by_bijection! { [SHTKey] <-> [u64]; forward(self) self
    .ukey; backward(x) SHTKey { ukey : x }; }

derive_marshalable_for_struct! { pub struct
    CKeyKV { pub k : CKey, pub v : Vec::< u8 >, } }

pub open spec fn ckeykv_ghost_serialize(kv: CKeyKV) -> Seq<u8> {
    kv.ghost_serialize()
}

pub open spec fn ckeykv_ghost_len(kv: CKeyKV) -> int {
    kv.ghost_serialize().len() as int
}

#[allow(non_snake_case)]
pub proof fn lemma_is_marshalable_CKeyHashMap(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
    ensures
        h.is_marshalable(),
{
    h.lemma_to_vec();
    let v = h.spec_to_vec();
    assert(v.len() == h@.dom().len());
    assert(v.len() < max_hashtable_size());
    assert(v@.len() < max_hashtable_size());
    assert(v@.len() <= usize::MAX);
    assert(spec_sorted_keys(v));

    // Every element of spec_to_vec is marshalable.
    assert forall|x: CKeyKV| v@.contains(x) implies #[trigger] x.is_marshalable() by {
        let i = choose|i: int| 0 <= i < v@.len() && v@[i] == x;
        assert(0 <= i < v@.len());
        assert(v@[i] == x);
        lemma_spec_to_vec_value_bound(h, i);
        assert(v@[i].v@.len() < max_val_len());
        assert(x.v@.len() < max_val_len());
        lemma_CKeyKV_is_marshalable(x);
        assert(x.is_marshalable());
    };

    // Each element's serialized length has a fixed upper bound.
    assert forall|i: int| 0 <= i < v@.len() implies v@[i].ghost_serialize().len() <= 16
        + max_val_len() by {
        lemma_spec_to_vec_value_bound(h, i);
        assert(v@[i].v@.len() < max_val_len());
        lemma_CKeyKV_ghost_serialize_len_bound(v@[i]);
        assert(v@[i].ghost_serialize().len() <= 16 + max_val_len());
    };

    // Bound the sum of the per-element serialized lengths.
    lemma_seq_fold_left_sum_le(v@, 0, 16 + max_val_len(), |a: CKeyKV| ckeykv_ghost_len(a));
    assert(v@.fold_left(0, |acc: int, x: CKeyKV| acc + ckeykv_ghost_len(x)) <= v@.len() * (16
        + max_val_len()));
    assert(v@.fold_left(0, |acc: int, x: CKeyKV| acc + ckeykv_ghost_len(x)) <= (
        max_hashtable_size() - 1) * (16 + max_val_len()));

    // The Vec serialization length is exactly the length of the length prefix plus the
    // fold of element serializations.
    lemma_seq_fold_left_append_len_int(v@, Seq::<u8>::empty(), |a: CKeyKV|
        ckeykv_ghost_serialize(a));
    assert(v@.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, a: CKeyKV| sb + ckeykv_ghost_serialize(
        a)).len() == v@.fold_left(0, |i: int, a: CKeyKV| i + ckeykv_ghost_serialize(a).len()
        as int));
    assert(v@.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, a: CKeyKV| sb + ckeykv_ghost_serialize(
        a)).len() <= (max_hashtable_size() - 1) * (16 + max_val_len()));

    lemma_auto_spec_u64_to_from_le_bytes();
    assert((v@.len() as usize).ghost_serialize().len() == 8);
    assert(v.ghost_serialize().len() <= 8 + (max_hashtable_size() - 1) * (16 + max_val_len()));

    // All three conjuncts of Vec::is_marshalable hold.
    assert((v@.len() as usize).ghost_serialize().len() + v@.fold_left(0, |acc: int,
        x: CKeyKV| acc + x.ghost_serialize().len()) <= usize::MAX);
    assert(v.is_marshalable());

    // Finally, the CKeyHashMap-level serialized-size cap.
    reveal_with_fuel(ckeyhashmap_max_serialized_size, 1);
    assert(v.ghost_serialize().len() <= ckeyhashmap_max_serialized_size() as int);
    assert(h.is_marshalable());
}

pub proof fn lemma_spec_to_vec_value_bound(h: CKeyHashMap, i: int)
    requires
        valid_hashtable(h@),
        0 <= i < h.spec_to_vec().len(),
    ensures
        h.spec_to_vec()[i].v@.len() < max_val_len(),
{
    h.lemma_to_vec();
    let (k, v) = h.spec_to_vec()[i]@;
    assert(h@.contains_pair(k, v));
    assert(h@.dom().contains(k));
    assert(h@[k] == v);
    assert(valid_value(h@[k]));
    assert(h@[k].len() < max_val_len());
    assert(v.len() < max_val_len());
    assert(h.spec_to_vec()[i].v@ == v);
    assert(h.spec_to_vec()[i].v@.len() < max_val_len());
}

pub proof fn lemma_CKeyKV_is_marshalable(kv: CKeyKV)
    requires
        kv.v@.len() < max_val_len(),
    ensures
        kv.is_marshalable(),
{
    lemma_auto_spec_u64_to_from_le_bytes();
    assert(kv.k.is_marshalable());
    assert(kv.v@.len() <= usize::MAX);
    assert((kv.v@.len() as usize).ghost_serialize().len() == 8);
    assert(kv.v.is_marshalable());
    assert(kv.k.ghost_serialize().len() == 8);
    assert(kv.v.ghost_serialize().len() == 8 + kv.v@.len());
    assert(kv.ghost_serialize().len() == 16 + kv.v@.len());
    assert(kv.ghost_serialize().len() <= 16 + max_val_len());
    assert(kv.is_marshalable());
}

pub proof fn lemma_CKeyKV_ghost_serialize_len_bound(kv: CKeyKV)
    requires
        kv.v@.len() < max_val_len(),
    ensures
        kv.ghost_serialize().len() <= 16 + max_val_len(),
{
    lemma_auto_spec_u64_to_from_le_bytes();
    assert(kv.k.ghost_serialize().len() == 8);
    assert(kv.v.ghost_serialize().len() == 8 + kv.v@.len());
    assert(kv.v@.len() < max_val_len());
    assert(kv.ghost_serialize().len() == 16 + kv.v@.len());
    assert(kv.ghost_serialize().len() <= 16 + max_val_len());
}

proof fn tmp_probe_fold(v: Vec<CKeyKV>)
    requires
        forall|i: int| 0 <= i < v@.len() ==> #[trigger] v@[i].is_marshalable(),
        forall|i: int| 0 <= i < v@.len() ==> v@[i].ghost_serialize().len() <= 1040,
{
    lemma_seq_fold_left_sum_le(v@, 0, 1040, |a: CKeyKV| a.ghost_serialize().len() as int);
    assert(v@.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len()) <= v@.len()
        * 1040);
}

} // verus!
