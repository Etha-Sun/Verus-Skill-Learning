use vstd::prelude::*;
use vstd::assert_seqs_equal;

fn main() {}

verus!{


pub proof fn seq_equal_preserved_by_add<A>(s1: Seq<A>, s2: Seq<A>, suffix: Seq<A>)
    ensures s1 == s2 <==> s1 + suffix == s2 + suffix
{
    assert(s1 == s2 ==> s1 + suffix == s2 + suffix) by {
        assert_seqs_equal!(s1 + suffix, s2 + suffix);
    }
    assert(s1 + suffix == s2 + suffix ==> s1 == s2) by {
        assert_seqs_equal!(s1, s2);
    }
}

}
