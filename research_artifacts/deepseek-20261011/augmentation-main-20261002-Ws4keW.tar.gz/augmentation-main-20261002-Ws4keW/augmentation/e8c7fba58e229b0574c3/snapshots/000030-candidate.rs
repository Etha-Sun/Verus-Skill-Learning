use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn temp_pred_equality<T>(p: TempPred<T>, q: TempPred<T>)
    requires
        p.entails(q),
        q.entails(p),
    ensures p == q,
	{
		unimplemented!()
	}

proof fn always_double_equality<T>(p: TempPred<T>)
    ensures always(always(p)) == always(p),
{
    let a1 = always(always(p));
    let a2 = always(p);

    assert(a1.entails(a2)) by {
        assert forall |ex: Execution<T>| !a1.satisfied_by(ex) || a2.satisfied_by(ex) by {
            if a1.satisfied_by(ex) {
                assert(a2.satisfied_by(ex)) by {
                    assert forall |k: nat| #[trigger] p.satisfied_by(ex.suffix(k)) by {
                        let s0 = ex.suffix(k);
                        assert(a2.satisfied_by(s0));
                        assert(p.satisfied_by(s0.suffix(0)));
                        let s0z = s0.suffix(0);
                        assert(s0z == s0) by {
                            assert forall |l: nat| #[trigger] (s0z.nat_to_state)(l) == (s0.nat_to_state)(l) by {
                                assert((l + 0) + k == l + k);
                            };
                            execution_equality(s0z, s0);
                        };
                        assert(p.satisfied_by(s0));
                    };
                };
            }
        };
    };

    assert(a2.entails(a1)) by {
        assert forall |ex: Execution<T>| !a2.satisfied_by(ex) || a1.satisfied_by(ex) by {
            if a2.satisfied_by(ex) {
                assert(a1.satisfied_by(ex)) by {
                    assert forall |i: nat, j: nat| #[trigger] p.satisfied_by(ex.suffix(i).suffix(j)) by {
                        assert(p.satisfied_by(ex.suffix(j + i)));
                        let sij = ex.suffix(i).suffix(j);
                        let sji = ex.suffix(j + i);
                        assert(sij == sji) by {
                            assert forall |l: nat| #[trigger] (sij.nat_to_state)(l) == (sji.nat_to_state)(l) by {
                                assert((l + j) + i == l + (j + i));
                            };
                            execution_equality(sij, sji);
                        };
                        assert(p.satisfied_by(sij));
                    };
                };
            }
        };
    };

    temp_pred_equality(a1, a2);
}


}
