# VeruSAGE Executive Skill

Repair only proof and ghost code. Preserve executable behavior, function
signatures, specifications, and termination requirements. Never introduce
`assume`, `admit`, `external_body`, new axioms, or a verification bypass.

Use the current Verus diagnostic as the primary signal. Before editing, classify
the failure (precondition, postcondition, invariant entry/exit, quantifier,
arithmetic, type/mode/scope, or termination), inspect the implicated context,
and choose the narrowest matching VeruSAGE action. Prefer an existing lemma or a
small local assertion over duplicating a proof. Re-run Verus after a meaningful
change; if the same failure repeats, change the proof strategy rather than
repeating the same edit. Accept a candidate only when Verus verifies it and the
proof-only safety comparison passes.

Before re-proving, scan for existing proof functions, `#[verifier::external_body]` lemmas, and provided temporal/state-machine lemmas whose conclusion matches the goal. Compose them (e.g., `always_unfold`, `always_p_is_stable`, `stable_and_n!`, `leads_to_exists_intro`, `entails_implies_leads_to`, `leads_to_trans`) instead of starting from scratch. When a supplied generic lemma does not fire because a `spec_fn` argument remains symbolic, instantiate it with an explicit term/trigger or write a specialized helper.

When discharging an existential goal, obtain a witness with `choose` and explicit `#[trigger]` annotations, assert the witness satisfies the property, and feed that witness to an existing proof-mode lemma when available. For temporal `leads_to` chains through existential states, use `leads_to_exists_intro`, `entails_implies_leads_to`, and `leads_to_trans`; bridge `lift_state(exists ...)` to `tla_exists(...)` with a pointwise `choose` witness assertion.

For properties of recursive spec functions (`set_fold`, `Seq::fold_left`, nat-indexed specs, etc.), introduce a recursive proof helper with a `decreases` clause mirroring the recursive definition, handle base and step cases explicitly, and call the helper from the original body. For opaque fold definitions use `reveal_with_fuel`; for `Execution` suffix equalities use `execution_equality` with pointwise equality rather than a direct assertion.

Treat spec-fn fields as fields, not methods: write `(x.field)(args)`, not `x.field(args)` (e.g., `nat_to_state`, `precondition`, `step_to_action`, `next_result`). To prove structural equality of a struct containing `spec_fn` fields, first assert the function fields are equal, then conclude struct equality.
