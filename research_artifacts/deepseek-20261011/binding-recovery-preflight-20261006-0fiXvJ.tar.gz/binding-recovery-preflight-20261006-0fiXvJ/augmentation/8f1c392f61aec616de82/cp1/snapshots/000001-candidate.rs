use vstd::{multiset::*, prelude::*};

fn main() {}

verus! {

#[verifier::external_body]
pub proof fn len_is_zero_means_count_for_each_value_is_zero<V>(m: Multiset<V>)
    ensures (forall |v| m.count(v) == 0) == (m.len() == 0),
{unimplemented!()}

pub proof fn filtered_size_is_zero_means_no_such_value<V>(m: Multiset<V>, f: spec_fn(V) -> bool)
    ensures (m.filter(f).len() == 0) == (forall |v: V| !(#[trigger] m.contains(v) && f(v)))
{
    len_is_zero_means_count_for_each_value_is_zero(m.filter(f));
    assert forall |v: V| #[trigger] (m.filter(f).count(v) == 0) <==> !(m.contains(v) && f(v)) by {
        assert(m.filter(f).count(v) == 0 ==> !(m.contains(v) && f(v)));
        assert(!(m.contains(v) && f(v)) ==> m.filter(f).count(v) == 0);
    }
    assert((forall |v: V| m.filter(f).count(v) == 0) == (forall |v: V| !(m.contains(v) && f(v))));
}

}
