use vstd::{multiset::*, prelude::*};

fn main() {}

verus! {

#[verifier::external_body]
pub proof fn len_is_zero_means_count_for_each_value_is_zero<V>(m: Multiset<V>)
    ensures (forall |v| m.count(v) == 0) == (m.len() == 0),
{unimplemented!()}

proof fn lemma_filter_count_zero_iff_no_such_value<V>(m: Multiset<V>, f: spec_fn(V) -> bool, v: V)
    ensures (m.filter(f).count(v) == 0) == !(m.contains(v) && f(v))
{
    axiom_filter_count(m, f, v);
    if f(v) {
        assert(m.filter(f).count(v) == m.count(v));
        assert((m.filter(f).count(v) == 0) == !(m.contains(v) && f(v)));
    } else {
        assert(m.filter(f).count(v) == 0);
        assert(!(m.contains(v) && f(v)));
    }
}

pub proof fn filtered_size_is_zero_means_no_such_value<V>(m: Multiset<V>, f: spec_fn(V) -> bool)
    ensures (m.filter(f).len() == 0) == (forall |v: V| !(#[trigger] m.contains(v) && f(v)))
{
    len_is_zero_means_count_for_each_value_is_zero(m.filter(f));
    assert forall |v: V|
        #![trigger (m.filter(f).count(v) == 0)]
        #![trigger (m.contains(v) && f(v))]
        (m.filter(f).count(v) == 0) == !(m.contains(v) && f(v))
        by {
        lemma_filter_count_zero_iff_no_such_value(m, f, v);
    };
    assert((m.filter(f).len() == 0) == (forall |v: V| !(m.contains(v) && f(v))));
}

}
