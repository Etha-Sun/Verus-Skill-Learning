extern crate verus_builtin_macros as builtin_macros;
use std::collections;
use vstd::bytes::*;
use vstd::prelude::*;
fn main() {}
verus! {

#[verifier(external_body)]
pub struct CKeyHashMap {
    m: collections::HashMap<CKey, Vec<u8>>,
}

impl CKeyHashMap {
    pub uninterp spec fn view(self) -> Map<AbstractKey, Seq<u8>>;

    pub uninterp spec fn spec_to_vec(&self) -> Vec<CKeyKV>;

    #[verifier(external_body)]
    #[verifier(when_used_as_spec(spec_to_vec))]
    pub fn to_vec(&self) -> (res: Vec<CKeyKV>) {
        unimplemented!()
    }

    pub uninterp spec fn spec_from_vec(v: Vec<CKeyKV>) -> Self;

    #[verifier::external_body]
    pub proof fn lemma_to_vec(self)
        ensures
            Self::spec_from_vec(self.spec_to_vec()) == self,
            self.spec_to_vec().len() == self@.dom().len(),
            spec_sorted_keys(self.spec_to_vec()),
            (forall|i: int|
                #![trigger(self.spec_to_vec() [i])]
                0 <= i < self.spec_to_vec().len() ==> {
                    let (k, v) = self.spec_to_vec()[i]@;
                    self@.contains_pair(k, v)
                }),
    {
        unimplemented!()
    }
}

pub struct CKeyKV {
    pub k: CKey,
    pub v: Vec<u8>,
}

impl CKeyKV {
    pub open spec fn view(self) -> (AbstractKey, Seq<u8>) {
        (self.k, self.v@)
    }
}

pub open spec fn ckeykvlt(a: CKeyKV, b: CKeyKV) -> bool {
    a.k.ukey < b.k.ukey
}

pub open spec fn spec_sorted_keys(v: Vec<CKeyKV>) -> bool {
    forall|i: int, j: int|
        0 <= i && i + 1 < v.len() && j == i + 1 ==> #[trigger] ckeykvlt(v@[i], v@[j])
}

#[derive(Eq, PartialEq, Hash)]
pub struct SHTKey {
    pub ukey: u64,
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_append_len_int<A, B>(
    s: Seq<A>,
    prefix: Seq<B>,
    f: spec_fn(A) -> Seq<B>,
)
    ensures
        s.fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a)).len() as int == s.fold_left(
            prefix.len() as int,
            |i: int, a: A| i + f(a).len() as int,
        ),
    decreases s.len(),
{
    unimplemented!()
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_sum_le<A>(s: Seq<A>, init: int, high: int, f: spec_fn(A) -> int)
    requires
        forall|i: int| 0 <= i < s.len() ==> f(s[i]) <= high,
    ensures
        s.fold_left(init, |acc: int, x: A| acc + f(x)) <= init + s.len() * high,
    decreases s.len(),
{
    unimplemented!()
}

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }
}

impl Marshalable for usize {
    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }
}

impl<T: Marshalable, U: Marshalable> Marshalable for (T, U) {
    open spec fn is_marshalable(&self) -> bool {
        &&& self.0.is_marshalable()
        &&& self.1.is_marshalable()
        &&& self.0.ghost_serialize().len() + self.1.ghost_serialize().len() <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.0.ghost_serialize() + self.1.ghost_serialize()
    }
}

macro_rules! derive_marshalable_for_struct { { $(#[$attr :
    meta])* $pub : vis struct $newstruct : ident $(< $($poly : ident : Marshalable),+
    $(,)? >)? { $($fieldvis : vis $field : ident : $fieldty : ty),+ $(,)? } } => {
    ::builtin_macros::verus! { impl $(< $($poly : Marshalable),* >)? Marshalable for
    $newstruct $(< $($poly),* >)? { open spec fn is_marshalable(& self) -> bool { $(&&&
    self.$field .is_marshalable())* &&& 0 $(+ self.$field .ghost_serialize().len())* <=
    usize::MAX } open spec fn ghost_serialize(& self) -> Seq < u8 > { Seq::empty() $(+
    self.$field .ghost_serialize())* } } } } }

macro_rules! marshalable_by_bijection { {
    [$type : ty] <-> [$marshalable : ty]; forward($self : ident) $forward : expr;
    backward($m : ident) $backward : expr; } => { ::builtin_macros::verus! { impl $type {
    pub open spec fn
    forward_bijection_for_view_equality_do_not_use_for_anything_else($self : Self) ->
    $marshalable { $forward } } impl Marshalable for $type { open spec fn
    is_marshalable($self : & Self) -> bool { $forward .is_marshalable() } open spec fn
    ghost_serialize($self : & Self) -> Seq < u8 > { $forward .ghost_serialize() } } } } }

#[verifier::opaque]
pub open spec fn ckeyhashmap_max_serialized_size() -> usize {
    0x100000
}

impl Marshalable for CKeyHashMap {
    open spec fn is_marshalable(&self) -> bool {
        self.to_vec().is_marshalable() && spec_sorted_keys(self.to_vec())
            && self.to_vec().ghost_serialize().len() <= (ckeyhashmap_max_serialized_size() as int)
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.to_vec().ghost_serialize()
    }
}

pub open spec fn max_val_len() -> int {
    1024
}

pub open spec fn valid_key(key: AbstractKey) -> bool {
    true
}

pub open spec fn valid_value(value: AbstractValue) -> bool {
    value.len() < max_val_len()
}

pub open spec fn max_hashtable_size() -> int {
    62
}

pub open spec fn valid_hashtable(h: Hashtable) -> bool {
    &&& h.dom().len() < max_hashtable_size()
    &&& (forall|k| h.dom().contains(k) ==> valid_key(k) && #[trigger] valid_value(h[k]))
}

pub type CKey = SHTKey;

pub type AbstractKey = SHTKey;

pub type AbstractValue = Seq<u8>;

pub type Hashtable = Map<AbstractKey, AbstractValue>;

marshalable_by_bijection! { [SHTKey] <-> [u64]; forward(self) self
    .ukey; backward(x) SHTKey { ukey : x }; }

derive_marshalable_for_struct! { pub struct
    CKeyKV { pub k : CKey, pub v : Vec::< u8 >, } }

#[allow(non_snake_case)]
pub proof fn lemma_u64_ser_len(x: u64)
    ensures
        x.ghost_serialize().len() == 8,
{
    spec_u64_to_le_bytes_to_open(x);
    assert(x.ghost_serialize() == spec_u64_to_le_bytes(x));
    assert(spec_u64_to_le_bytes(x) == spec_u64_to_le_bytes_open(x));
    assert(spec_u64_to_le_bytes_open(x).len() == 8);
}

#[allow(non_snake_case)]
pub proof fn lemma_usize_ser_len(x: usize)
    requires
        x as int <= u64::MAX,
    ensures
        x.ghost_serialize().len() == 8,
{
    lemma_u64_ser_len(x as u64);
    assert(x.ghost_serialize() == (x as u64).ghost_serialize());
    assert(x.ghost_serialize().len() == 8);
}

#[allow(non_snake_case)]
pub proof fn lemma_CKeyKV_bounds(kv: CKeyKV)
    requires
        valid_value(kv.v@),
    ensures
        kv.is_marshalable(),
        kv.ghost_serialize().len() <= 1039,
{
    assert(kv.k.is_marshalable());
    lemma_u64_ser_len(kv.k.ukey);
    assert(kv.k.ghost_serialize() == kv.k.ukey.ghost_serialize());
    assert(kv.k.ghost_serialize().len() == 8);

    assert(kv.v@.len() < 1024);
    assert(kv.v@.len() <= usize::MAX);
    assert(kv.v@.len() <= u64::MAX);
    lemma_usize_ser_len(kv.v@.len() as usize);
    assert((kv.v@.len() as usize).ghost_serialize().len() == 8);
    assert((kv.v@.len() as usize).ghost_serialize().len() + kv.v@.len() <= usize::MAX);
    assert(kv.v.is_marshalable());
    assert(kv.v.ghost_serialize() == (kv.v@.len() as usize).ghost_serialize() + kv.v@);
    assert(kv.v.ghost_serialize().len() == 8 + kv.v@.len());

    assert(kv.is_marshalable());
    assert(kv.ghost_serialize() == Seq::empty() + kv.k.ghost_serialize() + kv.v.ghost_serialize());
    assert(kv.ghost_serialize().len() == 8 + 8 + kv.v@.len());
    assert(kv.v@.len() <= 1023);
    assert(kv.ghost_serialize().len() <= 1039);
}

#[allow(non_snake_case)]
pub proof fn lemma_kv_at_index_marshalable(h: CKeyHashMap, i: int)
    requires
        valid_hashtable(h@),
        forall|i: int|
            #![trigger(h.spec_to_vec()[i])]
            0 <= i < h.spec_to_vec().len() ==> {
                let (k, v) = h.spec_to_vec()[i]@;
                h@.contains_pair(k, v)
            },
        0 <= i < h.spec_to_vec()@.len(),
    ensures
        h.spec_to_vec()@[i].is_marshalable(),
        h.spec_to_vec()@[i].ghost_serialize().len() <= 1039,
{
    let x = h.spec_to_vec()@[i];
    let (k, v) = x@;
    assert(h@.contains_pair(k, v));
    assert(h@.dom().contains(k));
    assert(h@[k] == v);
    assert(valid_key(k));
    assert(valid_value(h@[k]));
    assert(valid_value(v));
    lemma_CKeyKV_bounds(x);
}

#[allow(non_snake_case)]
pub proof fn test_forall_pattern(s: Seq<CKeyKV>)
    requires
        forall|i: int| 0 <= i < s.len() ==> s[i].is_marshalable(),
{
    assert forall|i: int| 0 <= i < s.len() implies s[i].is_marshalable() by {
        let i: int;
        if 0 <= i < s.len() {
            assert(s[i].is_marshalable());
        }
    }
}

#[allow(non_snake_case)]
pub proof fn test_lemma_to_vec_discharge(h: CKeyHashMap)
    requires
        forall|i: int|
            #![trigger(h.spec_to_vec()[i])]
            0 <= i < h.spec_to_vec().len() ==> {
                let (k, v) = h.spec_to_vec()[i]@;
                h@.contains_pair(k, v)
            },
{
}

#[allow(non_snake_case)]
pub proof fn test_main_pattern(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
        forall|i: int|
            #![trigger(h.spec_to_vec()[i])]
            0 <= i < h.spec_to_vec().len() ==> {
                let (k, v) = h.spec_to_vec()[i]@;
                h@.contains_pair(k, v)
            },
{
    assert forall|i: int|
        #![trigger(h.spec_to_vec()@[i])]
        0 <= i < h.spec_to_vec()@.len() implies h.spec_to_vec()@[i].is_marshalable() by {
        let i: int;
        if 0 <= i < h.spec_to_vec()@.len() {
            lemma_kv_at_index_marshalable(h, i);
            assert(h.spec_to_vec()@[i].is_marshalable());
        }
    }
}

#[allow(non_snake_case)]
pub proof fn test_triv_call(h: CKeyHashMap, i: int)
    requires
        0 <= i < h.spec_to_vec()@.len(),
    ensures
        1 == 1,
{
}

#[allow(non_snake_case)]
pub proof fn test_helper_call_top(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
        forall|i: int|
            #![trigger(h.spec_to_vec()[i])]
            0 <= i < h.spec_to_vec().len() ==> {
                let (k, v) = h.spec_to_vec()[i]@;
                h@.contains_pair(k, v)
            },
        0 < h.spec_to_vec()@.len(),
{
    lemma_kv_at_index_marshalable(h, 0);
}

#[allow(non_snake_case)]
pub proof fn test_main_pattern2(h: CKeyHashMap)
{
    assert forall|i: int|
        #![trigger(h.spec_to_vec()@[i])]
        0 <= i < h.spec_to_vec()@.len() implies 1 == 1 by {
        let i: int;
        if 0 <= i < h.spec_to_vec()@.len() {
            test_triv_call(h, i);
        }
    }
}

#[allow(non_snake_case)]
pub proof fn lemma_is_marshalable_CKeyHashMap(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
    ensures
        h.is_marshalable(),
{
    h.lemma_to_vec();

    test_lemma_to_vec_discharge(h);

    assert(spec_sorted_keys(h.spec_to_vec()));

    assert(h.spec_to_vec().len() == h@.dom().len());
    assert(h@.dom().len() < max_hashtable_size());
    assert(max_hashtable_size() == 62);
    assert(h.spec_to_vec()@.len() <= 61);
    assert(h.spec_to_vec()@.len() <= usize::MAX);
    assert(h.spec_to_vec()@.len() <= u64::MAX);

    assert forall|i: int|
        0 <= i < h.spec_to_vec()@.len() implies h.spec_to_vec()@[i].is_marshalable() by {
        let i: int;
        if 0 <= i < h.spec_to_vec()@.len() {
            lemma_kv_at_index_marshalable(h, i);
            assert(h.spec_to_vec()@[i].is_marshalable());
        }
    }

    assert(h.spec_to_vec().is_marshalable());

    lemma_usize_ser_len(h.spec_to_vec()@.len() as usize);
    assert((h.spec_to_vec()@.len() as usize).ghost_serialize().len() == 8);

    lemma_seq_fold_left_append_len_int(
        h.spec_to_vec()@,
        Seq::<u8>::empty(),
        |x: CKeyKV| x.ghost_serialize(),
    );
    lemma_seq_fold_left_sum_le(
        h.spec_to_vec()@,
        0,
        1039,
        |x: CKeyKV| x.ghost_serialize().len() as int,
    );

    assert(h.spec_to_vec()@.fold_left(
        Seq::<u8>::empty(),
        |acc: Seq<u8>, x: CKeyKV| acc + x.ghost_serialize(),
    ).len() as int <= h.spec_to_vec()@.len() * 1039);

    assert(h.spec_to_vec().ghost_serialize() == (h.spec_to_vec()@.len() as usize).ghost_serialize()
        + h.spec_to_vec()@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: CKeyKV| acc + x.ghost_serialize(),
        ));

    assert(h.spec_to_vec().ghost_serialize().len() <= 8 + h.spec_to_vec()@.len() * 1039);
    assert(h.spec_to_vec()@.len() * 1039 <= 61 * 1039);
    assert(8 + 61 * 1039 <= 0x100000);

    reveal(ckeyhashmap_max_serialized_size);
    assert(h.spec_to_vec().ghost_serialize().len() <= ckeyhashmap_max_serialized_size() as int);

    assert(h.is_marshalable());
}

} // verus!
