extern crate verus_builtin_macros as builtin_macros;
use std::collections;
use vstd::bytes::*;
use vstd::prelude::*;
use vstd::std_specs::vec::axiom_spec_len;
fn main() {}
verus! {

broadcast use vstd::seq::group_seq_axioms;

#[verifier(external_body)]
pub struct CKeyHashMap {
    m: collections::HashMap<CKey, Vec<u8>>,
}

impl CKeyHashMap {
    pub uninterp spec fn view(self) -> Map<AbstractKey, Seq<u8>>;

    pub uninterp spec fn spec_to_vec(&self) -> Vec<CKeyKV>;

    #[verifier(external_body)]
    #[verifier(when_used_as_spec(spec_to_vec))]
    pub fn to_vec(&self) -> (res: Vec<CKeyKV>) {
        unimplemented!()
    }

    pub uninterp spec fn spec_from_vec(v: Vec<CKeyKV>) -> Self;

    #[verifier::external_body]
    pub proof fn lemma_to_vec(self)
        ensures
            Self::spec_from_vec(self.spec_to_vec()) == self,
            self.spec_to_vec().len() == self@.dom().len(),
            spec_sorted_keys(self.spec_to_vec()),
            (forall|i: int|
                #![trigger(self.spec_to_vec() [i])]
                0 <= i < self.spec_to_vec().len() ==> {
                    let (k, v) = self.spec_to_vec()[i]@;
                    self@.contains_pair(k, v)
                }),
    {
        unimplemented!()
    }
}

pub struct CKeyKV {
    pub k: CKey,
    pub v: Vec<u8>,
}

impl CKeyKV {
    pub open spec fn view(self) -> (AbstractKey, Seq<u8>) {
        (self.k, self.v@)
    }
}

pub open spec fn ckeykvlt(a: CKeyKV, b: CKeyKV) -> bool {
    a.k.ukey < b.k.ukey
}

pub open spec fn spec_sorted_keys(v: Vec<CKeyKV>) -> bool {
    forall|i: int, j: int|
        0 <= i && i + 1 < v.len() && j == i + 1 ==> #[trigger] ckeykvlt(v@[i], v@[j])
}

#[derive(Eq, PartialEq, Hash)]
pub struct SHTKey {
    pub ukey: u64,
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_append_len_int<A, B>(
    s: Seq<A>,
    prefix: Seq<B>,
    f: spec_fn(A) -> Seq<B>,
)
    ensures
        s.fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a)).len() as int == s.fold_left(
            prefix.len() as int,
            |i: int, a: A| i + f(a).len() as int,
        ),
    decreases s.len(),
{
    unimplemented!()
}

#[verifier::external_body]
pub proof fn lemma_seq_fold_left_sum_le<A>(s: Seq<A>, init: int, high: int, f: spec_fn(A) -> int)
    requires
        forall|i: int| 0 <= i < s.len() ==> f(s[i]) <= high,
    ensures
        s.fold_left(init, |acc: int, x: A| acc + f(x)) <= init + s.len() * high,
    decreases s.len(),
{
    unimplemented!()
}

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }
}

impl Marshalable for usize {
    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }
}

impl<T: Marshalable, U: Marshalable> Marshalable for (T, U) {
    open spec fn is_marshalable(&self) -> bool {
        &&& self.0.is_marshalable()
        &&& self.1.is_marshalable()
        &&& self.0.ghost_serialize().len() + self.1.ghost_serialize().len() <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.0.ghost_serialize() + self.1.ghost_serialize()
    }
}

macro_rules! derive_marshalable_for_struct { { $(#[$attr :
    meta])* $pub : vis struct $newstruct : ident $(< $($poly : ident : Marshalable),+
    $(,)? >)? { $($fieldvis : vis $field : ident : $fieldty : ty),+ $(,)? } } => {
    ::builtin_macros::verus! { impl $(< $($poly : Marshalable),* >)? Marshalable for
    $newstruct $(< $($poly),* >)? { open spec fn is_marshalable(& self) -> bool { $(&&&
    self.$field .is_marshalable())* &&& 0 $(+ self.$field .ghost_serialize().len())* <=
    usize::MAX } open spec fn ghost_serialize(& self) -> Seq < u8 > { Seq::empty() $(+
    self.$field .ghost_serialize())* } } } } }

macro_rules! marshalable_by_bijection { {
    [$type : ty] <-> [$marshalable : ty]; forward($self : ident) $forward : expr;
    backward($m : ident) $backward : expr; } => { ::builtin_macros::verus! { impl $type {
    pub open spec fn
    forward_bijection_for_view_equality_do_not_use_for_anything_else($self : Self) ->
    $marshalable { $forward } } impl Marshalable for $type { open spec fn
    is_marshalable($self : & Self) -> bool { $forward .is_marshalable() } open spec fn
    ghost_serialize($self : & Self) -> Seq < u8 > { $forward .ghost_serialize() } } } } }

#[verifier::opaque]
pub open spec fn ckeyhashmap_max_serialized_size() -> usize {
    0x100000
}

impl Marshalable for CKeyHashMap {
    open spec fn is_marshalable(&self) -> bool {
        self.to_vec().is_marshalable() && spec_sorted_keys(self.to_vec())
            && self.to_vec().ghost_serialize().len() <= (ckeyhashmap_max_serialized_size() as int)
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        self.to_vec().ghost_serialize()
    }
}

pub open spec fn max_val_len() -> int {
    1024
}

pub open spec fn valid_key(key: AbstractKey) -> bool {
    true
}

pub open spec fn valid_value(value: AbstractValue) -> bool {
    value.len() < max_val_len()
}

pub open spec fn max_hashtable_size() -> int {
    62
}

pub open spec fn valid_hashtable(h: Hashtable) -> bool {
    &&& h.dom().len() < max_hashtable_size()
    &&& (forall|k| h.dom().contains(k) ==> valid_key(k) && #[trigger] valid_value(h[k]))
}

pub type CKey = SHTKey;

pub type AbstractKey = SHTKey;

pub type AbstractValue = Seq<u8>;

pub type Hashtable = Map<AbstractKey, AbstractValue>;

marshalable_by_bijection! { [SHTKey] <-> [u64]; forward(self) self
    .ukey; backward(x) SHTKey { ukey : x }; }

derive_marshalable_for_struct! { pub struct
    CKeyKV { pub k : CKey, pub v : Vec::< u8 >, } }

#[allow(non_snake_case)]
pub proof fn lemma_u64_ghost_serialize_len(x: u64)
    ensures
        x.ghost_serialize().len() == 8,
{
    spec_u64_to_le_bytes_to_open(x);
    assert(x.ghost_serialize() == spec_u64_to_le_bytes(x));
    assert(spec_u64_to_le_bytes(x) == spec_u64_to_le_bytes_open(x));
    assert(spec_u64_to_le_bytes_open(x).len() == 8);
    assert(x.ghost_serialize().len() == 8);
}

#[allow(non_snake_case)]
pub proof fn lemma_usize_ghost_serialize_len(x: usize)
    ensures
        x.ghost_serialize().len() == 8,
{
    spec_u64_to_le_bytes_to_open(x as u64);
    assert(x.is_marshalable());
    assert(x.ghost_serialize() == (x as u64).ghost_serialize());
    assert((x as u64).ghost_serialize() == spec_u64_to_le_bytes(x as u64));
    assert(spec_u64_to_le_bytes(x as u64) == spec_u64_to_le_bytes_open(x as u64));
    assert(spec_u64_to_le_bytes_open(x as u64).len() == 8);
    assert(x.ghost_serialize().len() == 8);
}

#[allow(non_snake_case)]
pub proof fn lemma_CKeyKV_is_marshalable(kv: CKeyKV)
    requires
        valid_value(kv.v@),
    ensures
        kv.is_marshalable(),
{
    assert(kv.k.is_marshalable());
    assert(kv.v.is_marshalable()) by {
        assert(kv.v@.len() <= usize::MAX);
        assert(kv.v@.len() < 1024);
        lemma_usize_ghost_serialize_len(kv.v@.len() as usize);
        assert((kv.v@.len() as usize).ghost_serialize().len() == 8);
        assert((kv.v@.len() as usize).ghost_serialize().len() + kv.v@.len() <= usize::MAX);
    }
    lemma_u64_ghost_serialize_len(kv.k.ukey);
    assert(kv.k.ghost_serialize() == kv.k.ukey.ghost_serialize());
    assert(kv.k.ghost_serialize().len() == 8);
    assert(kv.v.ghost_serialize() == (kv.v@.len() as usize).ghost_serialize() + kv.v@);
    assert(kv.v.ghost_serialize().len() == 8 + kv.v@.len());
    assert(kv.k.ghost_serialize().len() + kv.v.ghost_serialize().len() <= usize::MAX);
    assert(kv.is_marshalable());
}

#[allow(non_snake_case)]
pub proof fn lemma_spec_to_vec_element(h: CKeyHashMap, i: int)
    requires
        valid_hashtable(h@),
        0 <= i < h.spec_to_vec().len(),
    ensures
        valid_value(h.spec_to_vec()[i].v@),
        h.spec_to_vec()[i].is_marshalable(),
{
    h.lemma_to_vec();
    let kv = h.spec_to_vec()[i];
    assert(h@.contains_pair(kv.k, kv.v@));
    assert(h@.dom().contains(kv.k));
    assert(valid_value(h@[kv.k]));
    assert(h@[kv.k] == kv.v@);
    assert(valid_value(kv.v@));
    lemma_CKeyKV_is_marshalable(kv);
    assert(kv.is_marshalable());
    assert(h.spec_to_vec()[i].is_marshalable());
}

#[allow(non_snake_case)]
pub proof fn lemma_is_marshalable_CKeyHashMap(h: CKeyHashMap)
    requires
        valid_hashtable(h@),
    ensures
        h.is_marshalable(),
{
    h.lemma_to_vec();
    let v = h.spec_to_vec();
    axiom_spec_len(&v);
    assert(v.len() == v@.len());

    assert(v@.len() == h@.dom().len());
    assert(v@.len() < 62);
    assert(v@.len() <= usize::MAX);

    // every element of the serialized vector is marshalable
    assert(forall|x: CKeyKV| v@.contains(x) ==> #[trigger] x.is_marshalable()) by {
        let idx = v@.lemma_contains_to_index(x);
        lemma_spec_to_vec_element(h, idx);
        assert(v@[idx] == x);
        assert(h.spec_to_vec()[idx] == v@[idx]);
        assert(h.spec_to_vec()[idx].is_marshalable());
        assert(x.is_marshalable());
    }

    // bound the serialized size of each element
    assert(forall|i: int| 0 <= i < v@.len() ==> v@[i].ghost_serialize().len() <= 1039) by {
        lemma_spec_to_vec_element(h, i);
        assert(valid_value(v@[i].v@));
        assert(v@[i].v@.len() <= 1023);
        assert(v@[i].is_marshalable());
        lemma_u64_ghost_serialize_len(v@[i].k.ukey);
        lemma_usize_ghost_serialize_len(v@[i].v@.len() as usize);
        assert(v@[i].k.ghost_serialize().len() == 8);
        assert(v@[i].v.ghost_serialize().len() == 8 + v@[i].v@.len());
        assert(v@[i].ghost_serialize().len() == v@[i].k.ghost_serialize().len()
            + v@[i].v.ghost_serialize().len());
        assert(v@[i].ghost_serialize().len() == 16 + v@[i].v@.len());
        assert(v@[i].ghost_serialize().len() <= 1039);
    }

    lemma_seq_fold_left_sum_le(v@, 0, 1039, |x: CKeyKV| x.ghost_serialize().len() as int);
    assert(v@.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len() as int)
        <= v@.len() * 1039);

    lemma_usize_ghost_serialize_len(v@.len() as usize);
    assert((v@.len() as usize).ghost_serialize().len() == 8);
    assert(8 + v@.len() * 1039 <= usize::MAX);
    assert((v@.len() as usize).ghost_serialize().len()
        + v@.fold_left(0, |acc: int, x: CKeyKV| acc + x.ghost_serialize().len() as int)
        <= usize::MAX);

    assert(v.is_marshalable());
    assert(spec_sorted_keys(v));

    // total serialized size stays within the cap
    lemma_seq_fold_left_append_len_int(v@, Seq::<u8>::empty(), |x: CKeyKV| x.ghost_serialize());
    assert(v@.fold_left(Seq::<u8>::empty(), |sb: Seq<u8>, x: CKeyKV| sb + x.ghost_serialize())
        .len() == v@.fold_left(0, |i: int, x: CKeyKV| i + x.ghost_serialize().len() as int));
    assert(v@.fold_left(0, |i: int, x: CKeyKV| i + x.ghost_serialize().len() as int)
        <= v@.len() * 1039);
    assert(v.ghost_serialize().len() <= 8 + v@.len() * 1039);
    assert(8 + v@.len() * 1039 <= 63387);
    reveal(ckeyhashmap_max_serialized_size);
    assert(ckeyhashmap_max_serialized_size() as int == 0x100000);
    assert(v.ghost_serialize().len() <= ckeyhashmap_max_serialized_size() as int);

    assert(h.is_marshalable());
}

} // verus!
