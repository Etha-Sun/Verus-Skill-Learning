use vstd::prelude::*;

fn main() {}

verus!{

// File: defs.rs
pub struct Execution<T> {
    pub nat_to_state: spec_fn(nat) -> T,
}

impl<T> Execution<T> {

    pub open spec fn suffix(self, pos: nat) -> Self {
        Execution {
            nat_to_state: |i: nat| (self.nat_to_state)(i + pos),
        }
    }

}


#[verifier(reject_recursive_types(T))]
pub struct TempPred<T> {
    pub pred: spec_fn(Execution<T>) -> bool,
}

impl<T> TempPred<T> {

    pub open spec fn new(pred: spec_fn(Execution<T>) -> bool) -> Self {
        TempPred {
            pred: pred,
        }
    }

    pub open spec fn satisfied_by(self, execution: Execution<T>) -> bool {
        (self.pred)(execution)
    }

    pub open spec fn and(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) && other.satisfied_by(ex))
    }

    pub open spec fn or(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) || other.satisfied_by(ex))
    }

    pub open spec fn implies(self, other: Self) -> Self {
        TempPred::new(|ex: Execution<T>| self.satisfied_by(ex) ==> other.satisfied_by(ex))
    }

    pub open spec fn leads_to(self, other: Self) -> Self {
        always(self.implies(eventually(other)))
    }

    pub open spec fn entails(self, other: Self) -> bool {
        valid(self.implies(other))
    }

}


pub open spec fn always<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| forall |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn eventually<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| exists |i: nat| #[trigger] temp_pred.satisfied_by(ex.suffix(i)))
}

pub open spec fn later<T>(temp_pred: TempPred<T>) -> TempPred<T> {
    TempPred::new(|ex: Execution<T>| temp_pred.satisfied_by(ex.suffix(1)))
}

pub open spec fn valid<T>(temp_pred: TempPred<T>) -> bool {
    forall |ex: Execution<T>| temp_pred.satisfied_by(ex)
}


// File: rules.rs
	#[verifier::external_body]
proof fn leads_to_unfold<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires p.leads_to(q).satisfied_by(ex),
    ensures forall |i: nat| p.implies(eventually(q)).satisfied_by(#[trigger] ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn implies_apply<T>(ex: Execution<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        p.implies(q).satisfied_by(ex),
        p.satisfied_by(ex),
    ensures q.satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn always_propagate_forwards<T>(ex: Execution<T>, p: TempPred<T>, i: nat)
    requires always(p).satisfied_by(ex),
    ensures always(p).satisfied_by(ex.suffix(i)),
	{
		unimplemented!()
	}

	#[verifier::external_body]
proof fn eventually_proved_by_witness<T>(ex: Execution<T>, p: TempPred<T>, witness_idx: nat)
    requires p.satisfied_by(ex.suffix(witness_idx)),
    ensures eventually(p).satisfied_by(ex)
	{
		unimplemented!()
	}

spec fn eventually_choose_witness<T>(ex: Execution<T>, p: TempPred<T>) -> nat
    recommends exists |i| p.satisfied_by(#[trigger] ex.suffix(i)),
{
    let witness = choose |i| p.satisfied_by(#[trigger] ex.suffix(i));
    witness
}

	#[verifier::external_body]
proof fn always_p_or_eventually_q<T>(ex: Execution<T>, next: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        always(p.and(next).implies(later(p).or(later(q)))).satisfied_by(ex),
        always(next).satisfied_by(ex),
    ensures always(p.implies(always(p).or(eventually(q)))).satisfied_by(ex),
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub proof fn execution_equality<T>(ex1: Execution<T>, ex2: Execution<T>)
    requires forall |i: nat| #[trigger] (ex1.nat_to_state)(i) == (ex2.nat_to_state)(i),
    ensures ex1 == ex2,
	{
		unimplemented!()
	}

pub proof fn wf1_variant_temp<T>(spec: TempPred<T>, next: TempPred<T>, forward: TempPred<T>, p: TempPred<T>, q: TempPred<T>)
    requires
        spec.entails(always(p.and(next).implies(later(p).or(later(q))))),
        spec.entails(always(p.and(next).and(forward).implies(later(q)))),
        spec.entails(always(next)),
        spec.entails(always(p).leads_to(forward)),
    ensures spec.entails(p.leads_to(q)),
{
    assert(forall |ex: Execution<T>| spec.satisfied_by(ex) ==> p.leads_to(q).satisfied_by(ex)) by {
        if spec.satisfied_by(ex) {
            assert(always(p.and(next).implies(later(p).or(later(q)))).satisfied_by(ex));
            assert(always(p.and(next).and(forward).implies(later(q))).satisfied_by(ex));
            assert(always(next).satisfied_by(ex));
            assert((always(p).leads_to(forward)).satisfied_by(ex));
            assert(forall |i: nat| p.implies(eventually(q)).satisfied_by(#[trigger] ex.suffix(i))) by {
                let t: Execution<T> = ex.suffix(i);
                if p.satisfied_by(t) {
                    always_p_or_eventually_q::<T>(ex, next, p, q);
                    assert(p.implies(always(p).or(eventually(q))).satisfied_by(#[trigger] ex.suffix(i)));
                    implies_apply::<T>(t, p, always(p).or(eventually(q)));
                    if always(p).satisfied_by(t) {
                        assert((always(p).implies(eventually(forward))).satisfied_by(#[trigger] ex.suffix(i)));
                        implies_apply::<T>(t, always(p), eventually(forward));
                        let w: nat = eventually_choose_witness::<T>(t, forward);
                        assert(forward.satisfied_by(#[trigger] t.suffix(w)));
                        always_propagate_forwards::<T>(ex, p.and(next).and(forward).implies(later(q)), i);
                        always_propagate_forwards::<T>(ex, next, i);
                        assert((p.and(next).and(forward).implies(later(q))).satisfied_by(#[trigger] t.suffix(w)));
                        assert(p.satisfied_by(#[trigger] t.suffix(w)));
                        assert(next.satisfied_by(#[trigger] t.suffix(w)));
                        implies_apply::<T>(t.suffix(w), p.and(next).and(forward), later(q));
                        execution_equality::<T>(t.suffix(w).suffix(1), t.suffix(w + 1));
                        assert(q.satisfied_by(#[trigger] t.suffix(w + 1)));
                        eventually_proved_by_witness::<T>(t, q, w + 1);
                        assert(eventually(q).satisfied_by(t));
                    } else {
                        assert(eventually(q).satisfied_by(t));
                    }
                }
            };
        }
    };
}

proof fn probe_syntax1() {
    assert(forall |x: int| x < x + 1) by {
        assert(x < x + 1);
    };
}

proof fn probe_syntax2() {
    assert forall |x: int| x < x + 1 by {
        assert(x < x + 1);
    };
}

}
