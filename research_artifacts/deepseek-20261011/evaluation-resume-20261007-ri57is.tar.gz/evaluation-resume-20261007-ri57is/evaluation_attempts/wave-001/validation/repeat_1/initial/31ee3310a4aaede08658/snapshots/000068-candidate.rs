use std::collections;
use vstd::prelude::*;
fn main() {}
verus! {

#[derive(PartialEq, Eq, Hash)]
pub struct EndPoint {
    pub id: Vec<u8>,
}

impl EndPoint {
    pub open spec fn view(self) -> AbstractEndPoint {
        AbstractEndPoint { id: self.id@ }
    }
}

pub struct AbstractEndPoint {
    pub id: Seq<u8>,
}

impl AbstractEndPoint {
    pub open spec fn valid_physical_address(self) -> bool {
        self.id.len() < 0x100000
    }

    pub open spec fn abstractable(self) -> bool {
        self.valid_physical_address()
    }
}

#[verifier(external_body)]
#[verifier::accept_recursive_types(V)]
pub struct HashMap<V> {
    m: collections::HashMap<EndPoint, V>,
}

impl<V> HashMap<V> {
    pub uninterp spec fn view(self) -> Map<AbstractEndPoint, V>;

    #[verifier::external_body]
    pub fn insert(&mut self, key: &EndPoint, value: V)
        ensures
            self@ == old(self)@.insert(key@, value),
    {
        unimplemented!()
    }
}

pub type TombstoneTable = Map<AbstractEndPoint, nat>;

pub struct CTombstoneTable {
    pub epmap: HashMap<u64>,
}

impl CTombstoneTable {
    pub open spec fn abstractable(&self) -> bool {
        forall|k: AbstractEndPoint| #[trigger] self@.contains_key(k) ==> k.valid_physical_address()
    }

    pub open spec fn view(&self) -> TombstoneTable {
        self.epmap@.map_values(|v: u64| v as nat)
    }

    pub fn insert(&mut self, src: &EndPoint, last_seqno: u64)
        requires
            old(self).abstractable(),
            src@.valid_physical_address(),
        ensures
            self@ =~= old(self)@.insert(src@, last_seqno as nat),
            self.abstractable(),
    {
        let old_epmap_view: Map<AbstractEndPoint, u64> = self.epmap@;
        let old_table_view: TombstoneTable = self@;
        let src_view: AbstractEndPoint = src@;
        self.epmap.insert(src, last_seqno);
        assert forall|k: AbstractEndPoint| #[trigger] self@.contains_key(k) implies k.valid_physical_address() by {
            assert(self.epmap@.contains_key(k));
            assert(old_epmap_view.insert(src_view, last_seqno).contains_key(k));
            assert(old_epmap_view.contains_key(k) || k == src_view);
            if old_epmap_view.contains_key(k) {
                assert(old_table_view.contains_key(k));
                assert(k.valid_physical_address());
            } else {
                assert(k == src_view);
                assert(src_view.valid_physical_address());
                assert(k.valid_physical_address());
            }
        };
    }
}

} // verus!
