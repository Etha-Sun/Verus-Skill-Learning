use vstd::bytes::*;
use vstd::prelude::*;
fn main() {}
verus! {

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }

    spec fn view_equal(&self, other: &Self) -> bool;

    #[verifier::external_body]
    proof fn lemma_serialize_injective(&self, other: &Self)
        requires
            self.is_marshalable(),
            other.is_marshalable(),
            self.ghost_serialize() == other.ghost_serialize(),
        ensures
            self.view_equal(other),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl Marshalable for usize {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn view_equal(&self, other: &Self) -> bool {
        let s = self@;
        let o = other@;
        s.len() == o.len() && (forall|i: int|
            0 <= i < s.len() ==> #[trigger] s[i].view_equal(&o[i]))
    }

    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }

    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        let ghost s = self@;
        let ghost o = other@;
        let ghost ns = s.len() as usize;
        let ghost no = o.len() as usize;
        let ghost hs = ns.ghost_serialize();
        let ghost ho = no.ghost_serialize();

        // The u64 little-endian encoding is exactly 8 bytes, and decoding an
        // encoding returns the original value.
        vstd::bytes::lemma_auto_spec_u64_to_from_le_bytes();
        assert(hs.len() == 8);
        assert(ho.len() == 8);

        // Unfold the serialization into header followed by payload.
        assert(self.ghost_serialize() == hs + s);
        assert(other.ghost_serialize() == ho + o);
        assert(hs + s == ho + o);

        // The two serializations therefore share their 8-byte headers.
        assert forall|i: int| 0 <= i < 8 implies hs[i] == ho[i] by {
            assert(hs[i] == (hs + s)[i]);
            assert((hs + s)[i] == (ho + o)[i]);
            assert((ho + o)[i] == ho[i]);
        };
        vstd::assert_seqs_equal!(hs, ho);
        assert(hs == ho);

        // Equal length encodings are encodings of equal lengths.
        ns.lemma_serialize_injective(&no);
        assert(ns.view_equal(&no));
        assert(s.len() == o.len());

        // Now the payloads agree on every byte.
        assert forall|i: int| 0 <= i < s.len() implies s[i] == o[i] by {
            assert(s[i] == (hs + s)[8 + i]);
            assert((hs + s)[8 + i] == (ho + o)[8 + i]);
            assert((ho + o)[8 + i] == o[i]);
        };
        vstd::assert_seqs_equal!(s, o);
    }
}

} // verus!
