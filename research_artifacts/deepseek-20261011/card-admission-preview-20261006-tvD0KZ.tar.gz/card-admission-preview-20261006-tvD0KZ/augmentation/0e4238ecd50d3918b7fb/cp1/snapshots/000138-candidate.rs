use vstd::bytes::*;
use vstd::prelude::*;
fn main() {}
verus! {

pub trait Marshalable: Sized {
    spec fn is_marshalable(&self) -> bool;

    #[verifier::external_body]
    spec fn ghost_serialize(&self) -> Seq<u8>
        recommends
            self.is_marshalable(),
    {
        unimplemented!()
    }

    spec fn view_equal(&self, other: &Self) -> bool;

    #[verifier::external_body]
    proof fn lemma_serialize_injective(&self, other: &Self)
        requires
            self.is_marshalable(),
            other.is_marshalable(),
            self.ghost_serialize() == other.ghost_serialize(),
        ensures
            self.view_equal(other),
    {
        unimplemented!()
    }
}

impl Marshalable for u64 {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        true
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        spec_u64_to_le_bytes(*self)
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl Marshalable for usize {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        &&& *self as int <= u64::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (*self as u64).ghost_serialize()
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl<T: Marshalable> Marshalable for Vec<T> {
    open spec fn view_equal(&self, other: &Self) -> bool {
        let s = self@;
        let o = other@;
        s.len() == o.len() && (forall|i: int|
            0 <= i < s.len() ==> #[trigger] s[i].view_equal(&o[i]))
    }

    open spec fn is_marshalable(&self) -> bool {
        &&& self@.len() <= usize::MAX
        &&& (forall|x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
        &&& (self@.len() as usize).ghost_serialize().len() + self@.fold_left(
            0,
            |acc: int, x: T| acc + x.ghost_serialize().len(),
        ) <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@.fold_left(
            Seq::<u8>::empty(),
            |acc: Seq<u8>, x: T| acc + x.ghost_serialize(),
        )
    }

    #[verifier::external_body]
    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        unimplemented!()
    }
}

impl Marshalable for Vec<u8> {
    open spec fn view_equal(&self, other: &Self) -> bool {
        self@ === other@
    }

    open spec fn is_marshalable(&self) -> bool {
        self@.len() <= usize::MAX && (self@.len() as usize).ghost_serialize().len()
            + self@.len() as int <= usize::MAX
    }

    open spec fn ghost_serialize(&self) -> Seq<u8> {
        (self@.len() as usize).ghost_serialize() + self@
    }

    proof fn lemma_serialize_injective(self: &Self, other: &Self) {
        let ghost s = self@;
        let ghost o = other@;
        assert(s.len() <= usize::MAX);
        assert(o.len() <= usize::MAX);
        assert(s.len() <= u64::MAX);
        assert(o.len() <= u64::MAX);
        let ghost ns = s.len() as usize;
        let ghost no = o.len() as usize;
        let ghost hs = ns.ghost_serialize();
        let ghost ho = no.ghost_serialize();

        // Serializations agree by hypothesis; unfold the header + payload structure.
        assert(hs + s == ho + o);

        // The length header of both serializations is 8 bytes.
        vstd::bytes::lemma_auto_spec_u64_to_from_le_bytes();
        assert(hs.len() == 8);
        assert(ho.len() == 8);

        // Show the two headers agree on every byte, using the fact that
        // hs + s == ho + o holds by hypothesis.
        vstd::assert_seqs_equal!(hs, ho, i => {
            assert(hs[i] == (hs + s)[i]);
            assert((hs + s)[i] == (ho + o)[i]);
            assert((ho + o)[i] == ho[i]);
        });
        assert(hs == ho);

        // Equal headers decode to equal lengths via the round-trip property of the
        // little-endian encoding.
        assert(spec_u64_from_le_bytes(spec_u64_to_le_bytes(*ns as u64)) == *ns as u64);
        assert(spec_u64_from_le_bytes(spec_u64_to_le_bytes(*no as u64)) == *no as u64);
        assert(spec_u64_from_le_bytes(hs) == spec_u64_from_le_bytes(ho));
        assert(spec_u64_from_le_bytes(hs) == *ns as u64);
        assert(spec_u64_from_le_bytes(ho) == *no as u64);
        assert(*ns as u64 == *no as u64);
        assert(ns == no);
        assert(s.len() == o.len());

        // Now the payloads agree on every byte.
        vstd::assert_seqs_equal!(s, o, i => {
            assert(s[i] == (hs + s)[8 + i]);
            assert((hs + s)[8 + i] == (ho + o)[8 + i]);
            assert((ho + o)[8 + i] == o[i]);
        });
        assert(s == o);
    }
}

} // verus!

verus! {

proof fn probe_auto_explicit() {
    vstd::bytes::lemma_auto_spec_u64_to_from_le_bytes();
    let ghost v: u64 = 3;
    assert(spec_u64_to_le_bytes(v).len() == 8);
}

proof fn probe_auto_through_usize() {
    vstd::bytes::lemma_auto_spec_u64_to_from_le_bytes();
    let ghost ns: usize = 300;
    let ghost hs = ns.ghost_serialize();
    assert(hs.len() == 8);
}

proof fn probe_cast_exact_usize_u64() {
    let ghost x: usize = 300;
    let ghost y = x as u64;
    assert(y as int == 300);
}

proof fn probe_cast_roundtrip() {
    let ghost n: int = 300;
    let ghost ns = n as usize;
    assert(ns as int == 300);
}

proof fn probe_deep_eq() {
    let ghost s = seq![1u8, 2u8];
    let ghost o = seq![1u8, 2u8];
    assert(s == o);
    assert(s === o);
}

proof fn probe_usize_u64_inj(x: usize, y: usize)
    requires
        x as int <= u64::MAX,
        y as int <= u64::MAX,
        x as u64 == y as u64,
    ensures
        x == y,
{
}

} // verus!
