use vstd::prelude::*;
use vstd::seq_lib::*;
fn main() {}
verus! {

pub proof fn lemma_fold_left_concat_init<A, B>(acc: Seq<B>, s: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        s.fold_left(acc, |x: Seq<B>, a: A| x + f(a)) ==
        acc + s.fold_left(Seq::empty(), |x: Seq<B>, a: A| x + f(a)),
    decreases s.len(),
{
    let g = |x: Seq<B>, a: A| x + f(a);
    if s.len() == 0 {
        assert(s.fold_left(acc, g) == acc);
        assert(s.fold_left(Seq::empty(), g) == Seq::empty());
        assert(acc + Seq::empty() == acc) by {
            Seq::add_empty_right(acc, Seq::empty());
        }
    } else {
        let d = s.drop_last().fold_left(Seq::empty(), g);
        lemma_fold_left_concat_init(acc, s.drop_last(), f);
        assert(s.drop_last().fold_left(acc, g) == acc + d);
        assert(s.fold_left(acc, g) == (acc + d) + f(s.last()));
        assert(s.fold_left(Seq::empty(), g) == d + f(s.last()));
        assert_seqs_equal!((acc + d) + f(s.last()) == acc + (d + f(s.last())));
    }
}

pub proof fn lemma_fold_left_append_merge<A, B>(s1: Seq<A>, s2: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        (s1 + s2).fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) == s1.fold_left(
            Seq::empty(),
            |acc: Seq<B>, a: A| acc + f(a),
        ) + s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
{
    let g = |acc: Seq<B>, a: A| acc + f(a);
    (s1 + s2).lemma_fold_left_split(Seq::empty(), g, s1.len());
    assert_seqs_equal!((s1 + s2).subrange(0, s1.len()) == s1);
    assert_seqs_equal!((s1 + s2).subrange(s1.len(), (s1 + s2).len()) == s2);
    lemma_fold_left_concat_init(s1.fold_left(Seq::empty(), g), s2, f);
}

} // verus!
