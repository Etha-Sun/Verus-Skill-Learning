use vstd::prelude::*;
fn main() {}
verus! {

proof fn lemma_fold_left_append_merge_rec<A, B>(s1: Seq<A>, s2: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        (s1 + s2).fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)) == s1.fold_left(
            Seq::<B>::empty(),
            |acc: Seq<B>, a: A| acc + f(a),
        ) + s2.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)),
    decreases s2.len(),
{
    reveal_with_fuel(Seq::fold_left, 3);
    if s2.len() == 0 {
        assert(s2 =~= Seq::<A>::empty());
        assert((s1 + s2) =~= s1);
        assert(s2.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)) =~= Seq::<B>::empty());
        assert(
            (s1.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)) + Seq::<B>::empty())
                =~= s1.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a))
        );
    } else {
        let t = s2.drop_last();
        let last = s2.last();
        lemma_fold_left_append_merge_rec(s1, t, f);
        Seq::drop_last_distributes_over_add(s1, s2);
        vstd::seq_lib::lemma_append_last(s1, s2);
        vstd::seq_lib::lemma_concat_associative(
            s1.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)),
            t.fold_left(Seq::<B>::empty(), |acc: Seq<B>, a: A| acc + f(a)),
            f(last),
        );
    }
}

pub proof fn lemma_fold_left_append_merge<A, B>(s1: Seq<A>, s2: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        (s1 + s2).fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) == s1.fold_left(
            Seq::empty(),
            |acc: Seq<B>, a: A| acc + f(a),
        ) + s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
{
    lemma_fold_left_append_merge_rec(s1, s2, f);
}

} // verus!
