use vstd::prelude::*;
fn main() {}
verus! {

pub proof fn lemma_seq_append_assoc<A>(a: Seq<A>, b: Seq<A>, c: Seq<A>)
    ensures
        (a + b) + c == a + (b + c),
{
    vstd::assert_seqs_equal!((a + b) + c, a + (b + c));
}

pub proof fn lemma_fold_left_append_merge_aux<A, B>(s1: Seq<A>, s2: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        (s1 + s2).fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) == s1.fold_left(
            Seq::empty(),
            |acc: Seq<B>, a: A| acc + f(a),
        ) + s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
    decreases s2.len(),
{
    if s2.len() == 0 {
        vstd::assert_seqs_equal!(s1 + s2, s1);
        assert(s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) == Seq::empty());
        vstd::assert_seqs_equal!(
            s1.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) + Seq::empty(),
            s1.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a))
        );
    } else {
        let s2_rest = s2.drop_last();
        let last = s2.last();
        vstd::assert_seqs_equal!((s1 + s2).drop_last(), s1 + s2_rest);
        assert((s1 + s2).last() == last);
        let d = (s1 + s2).drop_last();
        let l = (s1 + s2).last();
        let lhs = (s1 + s2).fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a));
        let rhs = d.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) + f(l);
        assert(lhs == rhs);
        let lhs2 = s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a));
        let rhs2 = s2_rest.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) + f(last);
        assert(lhs2 == rhs2);
        lemma_fold_left_append_merge_aux(s1, s2_rest, f);
        lemma_seq_append_assoc(
            s1.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
            s2_rest.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
            f(last),
        );
    }
}

pub proof fn lemma_fold_left_append_merge<A, B>(s1: Seq<A>, s2: Seq<A>, f: spec_fn(A) -> Seq<B>)
    ensures
        (s1 + s2).fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)) == s1.fold_left(
            Seq::empty(),
            |acc: Seq<B>, a: A| acc + f(a),
        ) + s2.fold_left(Seq::empty(), |acc: Seq<B>, a: A| acc + f(a)),
{
    lemma_fold_left_append_merge_aux(s1, s2, f);
}

} // verus!
